package containers;

import java.io.Serializable;

public class CashContainer implements Serializable{

	private String token;
	private int id;
	private String value;
	
	public CashContainer()
	{
		
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}
	
	
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}


}

