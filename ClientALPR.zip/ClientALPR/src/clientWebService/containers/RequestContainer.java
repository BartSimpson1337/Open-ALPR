package containers;

import java.io.Serializable;
import java.util.List;

import request.Data;

public class RequestContainer implements Serializable{

	private String token;
	private int clientid;
	private int type;
	private Data data;
	
	
	public RequestContainer()
	{
		
	}

	public String getToken() {
		return token;
	}


	public void setToken(String token) {
		this.token = token;
	}

	public int getClientid() {
		return clientid;
	}
	
	public void setClientid(int clientid) {
		this.clientid = clientid;
	}


	public int getType() {
		return type;
	}


	public void setType(int type) {
		this.type = type;
	}

	public Data getData() {
		return data;
	}

	public void setData(Data data) {
		this.data = data;
	}





}
