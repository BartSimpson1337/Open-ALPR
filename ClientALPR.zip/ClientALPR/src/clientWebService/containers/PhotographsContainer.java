package containers;

public class PhotographsContainer {

	private int vehicleid;
	private byte[][] photos;
	
	public PhotographsContainer()
	{
	}

	public int getVehicleid() {
		return vehicleid;
	}

	public void setVehicleid(int vehicleid) {
		this.vehicleid = vehicleid;
	}

	public byte[][] getPhotos() {
		return photos;
	}

	public void setPhotos(byte[][] photos) {
		this.photos = photos;
	}
	
	
}
