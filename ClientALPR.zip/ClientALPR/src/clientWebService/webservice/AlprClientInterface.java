package webservice;


import java.util.List;

import request.Data;
import containers.*;
public interface AlprClientInterface {

	boolean userAuthentication();
	int isAlive() throws Exception;
	boolean login(String email, String password) throws Exception;
	boolean logout(int id) throws Exception;
	boolean register(String name, String birth_date, int contact, String email, String password) throws Exception;
	ClientContainer myAccount(int id) throws Exception;
	boolean withdraw(int id, String value) throws Exception;
	boolean deposit(int id, String value) throws Exception;
	boolean request(int id, int type, Data data) throws Exception;
	boolean addAdvertising(String date, String title, String reward, String localization, String description, int vehicleid) throws Exception;
	List<AdvertisingsContainer> Advertisings() throws Exception;
	boolean addVehicle(String plate, String brand, String model, int registration_year, String color, String fuel, int hp, int cc, String description, int clientid) throws Exception;
	List<AdvertisingsContainer> myAdvertisings(int id) throws Exception;
	List<AdvertisingsContainer> AdvertisingsByLocation(String location) throws Exception;
	List<VehiclesContainer> myVehicles(int id) throws Exception;
	List<ResultsContainer> myResults(int id) throws Exception;
	List<AdvertisingsContainer> myRewards(int id) throws Exception;
	PhotographsContainer getPhotos(int vehicleid) throws Exception;
	int myId(String email) throws Exception;
	boolean rmAdvertising(int id) throws Exception;
	boolean rmVehicle(int id) throws Exception;
	boolean rmResult(int id) throws Exception;
	boolean addUserPhoto(int id, byte[] photo) throws Exception;
	boolean rmUserPhoto(int id) throws Exception;
	boolean upAdvertising(int id, String date, String title, String reward, String localization, String description, int vehicleid) throws Exception;
	boolean upVehicles(int id, String plate, String brand, String model, int registration_year, String color, String fuel, int hp, int cc, String description, int clientid) throws Exception;
	
}
