package webservice;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import javax.annotation.processing.SupportedSourceVersion;
import javax.ws.rs.core.MediaType;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientHandlerException;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import com.sun.jersey.api.client.filter.HTTPBasicAuthFilter;
import com.sun.jersey.api.client.filter.LoggingFilter;
import com.sun.jersey.api.json.JSONConfiguration;
import com.sun.jersey.api.representation.Form;

import containers.AdvertisingsContainer;
import containers.CashContainer;
import containers.ClientContainer;
import containers.LoginContainer;
import containers.PhotographsContainer;
import containers.RegisterContainer;
import containers.RequestContainer;
import containers.ResultsContainer;
import containers.VehiclesContainer;
import request.Data;

public class AlprClientRemote implements AlprClientInterface {

	private static final HTTPBasicAuthFilter authFilter = new HTTPBasicAuthFilter("auth-user", "auth-pass");
	private static final String loginURL = "http://localhost:9998/Authentication";
	private static final String wsURL = "http://localhost:9998/WebService";
	private static String token;
	private static WebResource resource;
	private static Client client;
	private static ClientConfig config = new DefaultClientConfig();

	public AlprClientRemote()
	{

	}
	
	@Override
	public boolean userAuthentication()
	{
			try{
				
				client = Client.create(config);
				client.addFilter(authFilter);
				resource = client.resource(loginURL);
				
				ClientResponse response = resource.get(ClientResponse.class);
				if(response.getStatus() == 200)
				{
					
					token = response.getEntity(String.class);
					
					client.removeAllFilters();
					resource = client.resource(wsURL);
					
					return true;
				}		
		}
		catch(Exception e)
		{
		}
		return false;
	}
	
	@Override
	public int isAlive() throws Exception
	{
		if(userAuthentication()) {
			ClientResponse response = resource.path("testConnection").get(ClientResponse.class);
			return response.getClientResponseStatus().getStatusCode();
		}
		return 0;
	}
	
	
	@Override
	public boolean login(String email, String passowrd) throws Exception 
	{
		if(userAuthentication())
		{
			LoginContainer loginContainer = new LoginContainer();
				loginContainer.setToken(token);
				loginContainer.setEmail(email);
				loginContainer.setPassword(passowrd);
			
			ObjectMapper mapper = new ObjectMapper();
			String json = mapper.writeValueAsString(loginContainer);
			
			Form form = new Form();
				form.add("param", json);
			
			ClientResponse response = resource.path("method_1").accept(MediaType.TEXT_PLAIN).post(ClientResponse.class, form);
			return Boolean.valueOf(response.getEntity(String.class));
		}
		return false;
	}
	
	@Override
	public boolean logout(int id) throws Exception
	{
		if(userAuthentication())
		{
			Form form = new Form();
				form.add("param", token);
				form.add("param2", String.valueOf(id));
				
			ClientResponse response = resource.path("method_2").accept(MediaType.TEXT_PLAIN).post(ClientResponse.class, form);
			return Boolean.valueOf(response.getEntity(String.class));
		}
		return false;
	}
	
	@Override
	public boolean register(String name, String birth_date, int contact, String email, String password) throws Exception
	{
		if(userAuthentication())
		{
			RegisterContainer registerContainer = new RegisterContainer();
				registerContainer.setToken(token);
				registerContainer.setName(name);
				registerContainer.setBirth_date(birth_date);
				registerContainer.setContact(contact);
				registerContainer.setEmail(email);
				registerContainer.setPassword(password);
			
			//convert java object to json
			ObjectMapper mapper = new ObjectMapper();
			String json = mapper.writeValueAsString(registerContainer);
			
			Form form = new Form();
				form.add("param", json);
			
			ClientResponse response = resource.path("method_3").accept(MediaType.TEXT_PLAIN).post(ClientResponse.class, form);
			return Boolean.valueOf(response.getEntity(String.class));
		}
		return false;
	}
	
	@Override
	public ClientContainer myAccount(int id) throws Exception
	{
		if(userAuthentication())
		{

		  Form form = new Form();
			form.add("param", token);
		  	form.add("param2", String.valueOf(id));
			
          ClientResponse response = resource.path("method_4").accept(MediaType.APPLICATION_JSON).post(ClientResponse.class, form);
          String jsonString = response.getEntity(String.class);
	
		  ObjectMapper mapper = new ObjectMapper();
		  ClientContainer clientContainer = mapper.readValue(jsonString, new TypeReference<ClientContainer>(){});
		 
		  return clientContainer;
		}
		return null;
	}
	
	@Override
	public boolean withdraw(int id, String value) throws Exception
	{
		if(userAuthentication())
		{
			CashContainer cashContainer = new CashContainer();
				cashContainer.setToken(token);
				cashContainer.setId(id);
				cashContainer.setValue(value);
				
			//convert java object to json
			ObjectMapper mapper = new ObjectMapper();
			String json = mapper.writeValueAsString(cashContainer);
			
			Form form = new Form();
				form.add("param", json);
					
			ClientResponse response = resource.path("method_5").accept(MediaType.TEXT_PLAIN).post(ClientResponse.class, form);
			return Boolean.valueOf(response.getEntity(String.class));
		}
		return false;
	}
	
	@Override
	public boolean deposit(int id, String value) throws Exception
	{
		if(userAuthentication())
		{
			CashContainer cashContainer = new CashContainer();
				cashContainer.setToken(token);
				cashContainer.setId(id);
				cashContainer.setValue(value);
			
			//convert java object to json
			ObjectMapper mapper = new ObjectMapper();
			String json = mapper.writeValueAsString(cashContainer);
			
			Form form = new Form();
				form.add("param", json);
			
			ClientResponse response = resource.path("method_6").accept(MediaType.TEXT_PLAIN).post(ClientResponse.class, form);
			return Boolean.valueOf(response.getEntity(String.class));
		}
		return false;	
	}
	
	@Override
	public boolean request(int id, int type, Data data) throws Exception
	{
		if(userAuthentication())
		{
			RequestContainer requestContainer = new RequestContainer();
				requestContainer.setToken(token);
				requestContainer.setClientid(id);
				requestContainer.setType(type);
				requestContainer.setData(data);
			
			//convert java object to json
			ObjectMapper mapper = new ObjectMapper();
			String json = mapper.writeValueAsString(requestContainer);
				
			Form form = new Form();
				form.add("param", json);
			
			ClientResponse response = resource.path("method_7").accept(MediaType.TEXT_PLAIN).post(ClientResponse.class, form);
			return Boolean.valueOf(response.getEntity(String.class));
		}
		return false;
	}
	
	@Override
	public boolean addAdvertising(String date, String title, String reward, String localization, String description, int vehicleid) throws Exception
	{
		if(userAuthentication())
		{
			AdvertisingsContainer advertisingsContainer = new AdvertisingsContainer();
				advertisingsContainer.setToken(token);
				advertisingsContainer.setDate(date);
				advertisingsContainer.setTitle(title);
				advertisingsContainer.setReward(reward);
				advertisingsContainer.setLocalization(localization);
				advertisingsContainer.setDescription(description);
				advertisingsContainer.setVehicleid(vehicleid);
				
			//convert java object to json
			ObjectMapper mapper = new ObjectMapper();
			String json = mapper.writeValueAsString(advertisingsContainer);
			
			Form form = new Form();
				form.add("param", json);
			
			ClientResponse response = resource.path("method_8").accept(MediaType.TEXT_PLAIN).post(ClientResponse.class, form);
			return Boolean.valueOf(response.getEntity(String.class));
		}
		return false;
	}
	
	@Override
	public List<AdvertisingsContainer> Advertisings() throws Exception
	{	
		if(userAuthentication())
		{
			Form form = new Form();
				form.add("param", token);
			
			ClientResponse response = resource.path("method_9").accept(MediaType.APPLICATION_JSON).post(ClientResponse.class, form);
			String json = response.getEntity(String.class);
			
			ObjectMapper mapper = new ObjectMapper();
			List<AdvertisingsContainer> advertisings = mapper.readValue(json, new TypeReference<List<AdvertisingsContainer>>(){});
			return advertisings;
		}
		return null;
	}
	
	@Override
	public boolean addVehicle(String plate, String brand, String model, int registration_year, String color, String fuel, int hp, int cc, String description, int clientid) throws Exception
	{
		if(userAuthentication())
		{
			VehiclesContainer vehiclesContainer = new VehiclesContainer();
				vehiclesContainer.setToken(token);
				vehiclesContainer.setPlate(plate);
				vehiclesContainer.setBrand(brand);
				vehiclesContainer.setModel(model);
				vehiclesContainer.setRegistration_year(registration_year);
				vehiclesContainer.setColor(color);
				vehiclesContainer.setFuel(fuel);
				vehiclesContainer.setHp(hp);
				vehiclesContainer.setCc(cc);
				vehiclesContainer.setDescription(description);
				vehiclesContainer.setClientid(clientid);
				
			//convert java object to json
			ObjectMapper mapper = new ObjectMapper();
			String json = mapper.writeValueAsString(vehiclesContainer);
				
			Form form = new Form();
			form.add("param", json);
		
			ClientResponse response = resource.path("method_10").accept(MediaType.TEXT_PLAIN).post(ClientResponse.class, form);
			return Boolean.valueOf(response.getEntity(String.class));
		
		}
		return false;
	}
	
	@Override
	public List<AdvertisingsContainer> myAdvertisings(int id) throws Exception
	{
		if(userAuthentication())
		{
			Form form = new Form();
				form.add("param", token);
				form.add("param2", String.valueOf(id));
				
			ClientResponse response = resource.path("method_11").accept(MediaType.APPLICATION_JSON).post(ClientResponse.class, form);
			String json = response.getEntity(String.class);
				
			ObjectMapper mapper = new ObjectMapper();
				List<AdvertisingsContainer> advertisings = mapper.readValue(json, new TypeReference<List<AdvertisingsContainer>>(){});
				
			return advertisings;
		}
		return null;
	}
	
	@Override
	public List<AdvertisingsContainer> AdvertisingsByLocation(String location) throws Exception
	{
		if(userAuthentication())
		{
			Form form = new Form();
				form.add("param", token);
				form.add("param2", location);
				
			ClientResponse response = resource.path("method_12").accept(MediaType.APPLICATION_JSON).post(ClientResponse.class, form);
			String json = response.getEntity(String.class);	
			
			ObjectMapper mapper = new ObjectMapper();
				List<AdvertisingsContainer> advertisings = mapper.readValue(json, new TypeReference<List<AdvertisingsContainer>>(){});
			
			return advertisings;
		}
		return null;
	}
	
	@Override
	public List<VehiclesContainer> myVehicles(int id) throws Exception
	{
		if(userAuthentication())
		{
			Form form = new Form();
				form.add("param", token);
				form.add("param2", String.valueOf(id));
				
			ClientResponse response = resource.path("method_13").accept(MediaType.APPLICATION_JSON).post(ClientResponse.class, form);
			String json = response.getEntity(String.class);	
			
			ObjectMapper mapper = new ObjectMapper();
				List<VehiclesContainer> vehicles = mapper.readValue(json, new TypeReference<List<VehiclesContainer>>(){});
				
			return vehicles;
		}
		return null;
	}
	
	@Override
	public List<ResultsContainer> myResults(int id) throws Exception
	{
		if(userAuthentication())
		{
			Form form = new Form();
				form.add("param", token);
				form.add("param2", String.valueOf(id));
				
			ClientResponse response = resource.path("method_14").accept(MediaType.APPLICATION_JSON).post(ClientResponse.class, form);
			String json = response.getEntity(String.class);
			
			ObjectMapper mapper = new ObjectMapper();
				List<ResultsContainer> results = mapper.readValue(json, new TypeReference<List<ResultsContainer>>(){});
			
			return results;
		}
		return null;
	}
	
	@Override
	public List<AdvertisingsContainer> myRewards(int id) throws Exception
	{
		if(userAuthentication())
		{
			Form form = new Form();
				form.add("param", token);
				form.add("param2", String.valueOf(id));
			
			ClientResponse response = resource.path("method_15").accept(MediaType.APPLICATION_JSON).post(ClientResponse.class, form);
			String json = response.getEntity(String.class);
			
			ObjectMapper mapper = new ObjectMapper();
				List<AdvertisingsContainer> advertisings = mapper.readValue(json, new TypeReference<List<AdvertisingsContainer>>(){});
		
			return advertisings;
		}
		return null;
	}
	
	@Override
	public PhotographsContainer getPhotos(int vehicleid) throws Exception
	{
		if(userAuthentication())
		{
			Form form = new Form();
				form.add("param", token);
				form.add("param2", String.valueOf(vehicleid));
				
			ClientResponse response = resource.path("method_16").accept(MediaType.APPLICATION_JSON).post(ClientResponse.class, form);
			String json = response.getEntity(String.class);
			
			try
			{
			
			ObjectMapper mapper = new ObjectMapper();
				PhotographsContainer photographsContainer = mapper.readValue(json, new TypeReference<PhotographsContainer>(){});
			return photographsContainer;
			}
			catch(Exception e)
			{
				
			}
		}
		return null;
	}
	
	@Override
	public int myId(String email) throws Exception
	{
		if(userAuthentication())
		{
			Form form = new Form();
				form.add("param", token);
				form.add("param2", email);
			
			ClientResponse response = resource.path("method_17").accept(MediaType.TEXT_PLAIN).post(ClientResponse.class, form);
			String id = response.getEntity(String.class);
			
			return Integer.valueOf(id);
		}
		return 0;
	}

	@Override
	public boolean rmAdvertising(int id) throws Exception
	{
		if(userAuthentication())
		{
			Form form = new Form();
				form.add("param", token);
				form.add("param2", String.valueOf(id));
				
				ClientResponse response = resource.path("method_18").accept(MediaType.TEXT_PLAIN).post(ClientResponse.class, form);
			return Boolean.valueOf(response.getEntity(String.class));
		}
		return false;
	}
	
	@Override
	public boolean rmVehicle(int id) throws Exception
	{
		if(userAuthentication())
		{
			Form form = new Form();
				form.add("param", token);
				form.add("param2", String.valueOf(id));
				
				ClientResponse response = resource.path("method_19").accept(MediaType.TEXT_PLAIN).post(ClientResponse.class, form);
			return Boolean.valueOf(response.getEntity(String.class));
		}
		return false;
	}
	
	@Override
	public boolean rmResult(int id) throws Exception
	{
		if(userAuthentication())
		{
			Form form = new Form();
				form.add("param", token);
				form.add("param2", String.valueOf(id));
				
			ClientResponse response = resource.path("method_20").accept(MediaType.TEXT_PLAIN).post(ClientResponse.class, form);
			return Boolean.valueOf(response.getEntity(String.class));
		}
		return false;
	}
	
	@Override
	public boolean addUserPhoto(int id, byte[] photo) throws Exception
	{
		if(userAuthentication())
		{
			ClientContainer clientContainer = new ClientContainer();
				clientContainer.setToken(token);
				clientContainer.setId(id);
				clientContainer.setPhoto(photo);
				
			//convert java object to json
			ObjectMapper mapper = new ObjectMapper();
			String json = mapper.writeValueAsString(clientContainer);
			
			Form form = new Form();
				form.add("param", json);
				
			ClientResponse response = resource.path("method_21").accept(MediaType.TEXT_PLAIN).post(ClientResponse.class, form);
			return Boolean.valueOf(response.getEntity(String.class));
					
		}
		return false;
	}
	
	
	@Override
	public boolean rmUserPhoto(int id) throws Exception
	{
		if(userAuthentication())
		{
			Form form = new Form();
				form.add("param", token);
				form.add("param2", String.valueOf(id));

			ClientResponse response = resource.path("method_22").accept(MediaType.TEXT_PLAIN).post(ClientResponse.class, form);
			return Boolean.valueOf(response.getEntity(String.class));			
		}
		return false;
	}
	
	@Override
	public boolean upAdvertising(int id, String date, String title, String reward, String localization, String description, int vehicleid) throws Exception
	{
		if(userAuthentication())
		{
			AdvertisingsContainer advertisingsContainer = new AdvertisingsContainer();
				advertisingsContainer.setToken(token);
				advertisingsContainer.setId(id);
				advertisingsContainer.setDate(date);
				advertisingsContainer.setTitle(title);
				advertisingsContainer.setReward(reward);
				advertisingsContainer.setLocalization(localization);
				advertisingsContainer.setDescription(description);
				advertisingsContainer.setVehicleid(vehicleid);
				
			
			//convert java object to json
			ObjectMapper mapper = new ObjectMapper();
			String json = mapper.writeValueAsString(advertisingsContainer);
				
			Form form = new Form();
				form.add("param", json);
			
			ClientResponse response = resource.path("method_23").accept(MediaType.TEXT_PLAIN).post(ClientResponse.class, form);
			return Boolean.valueOf(response.getEntity(String.class));		
		}
		return false;
	}
	
	@Override
	public boolean upVehicles(int id, String plate, String brand, String model, int registration_year, String color, String fuel, int hp, int cc, String description, int clientid) throws Exception
	{
		if(userAuthentication())
		{
			VehiclesContainer vehiclesContainer = new VehiclesContainer();
				vehiclesContainer.setId(id);
				vehiclesContainer.setPlate(plate);
				vehiclesContainer.setBrand(brand);
				vehiclesContainer.setModel(model);
				vehiclesContainer.setRegistration_year(registration_year);
				vehiclesContainer.setColor(color);
				vehiclesContainer.setFuel(fuel);
				vehiclesContainer.setHp(hp);
				vehiclesContainer.setCc(cc);
				vehiclesContainer.setDescription(description);
				vehiclesContainer.setClientid(clientid);
			
			//convert java object to json
			ObjectMapper mapper = new ObjectMapper();
			String json = mapper.writeValueAsString(vehiclesContainer);
			
			Form form = new Form();
				form.add("param", json);
		
			ClientResponse response = resource.path("method_24").accept(MediaType.TEXT_PLAIN).post(ClientResponse.class, form);
			return Boolean.valueOf(response.getEntity(String.class));		
				
		}
		return false;
	}
	
	
}
