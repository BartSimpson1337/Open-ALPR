package camera;

public class CameraParameters {

	private float sensorWidth;
	private float sensorHeight;
	private float focalLength;
	
	public CameraParameters()
	{
	}

	public float getSensorWidth() {
		return sensorWidth;
	}

	public void setSensorWidth(float sensorWidth) {
		this.sensorWidth = sensorWidth;
	}

	public float getSensorHeight() {
		return sensorHeight;
	}

	public void setSensorHeight(float sensorHeight) {
		this.sensorHeight = sensorHeight;
	}

	public float getFocallength() {
		return focalLength;
	}

	public void setFocallength(float focallenght) {
		this.focalLength = focallenght;
	}
}
