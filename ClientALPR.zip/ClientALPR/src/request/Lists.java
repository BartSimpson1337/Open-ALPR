package request;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import camera.CameraParameters;

public class Lists {

	private List<String> images = new ArrayList<String>();
	private List<CameraParameters> listOfCameraParameters = new ArrayList<CameraParameters>();
	
	public Lists()
	{
	}
	public void addParameter(CameraParameters cameraParameters)
	{
		if(this.listOfCameraParameters.size() <= 5)
		{
			this.listOfCameraParameters.add(cameraParameters);
		}
		else
		{
			System.out.println("max requestsize!");
		}
	}
	public List<CameraParameters> getListOfCameraParameters()
	{
		return this.listOfCameraParameters;
	}
	public void addImage(String image)
	{
		if(this.images.size() <= 5)
		{
			this.images.add(image);
		}
		else
		{
			System.out.println("max request size!");
		}
	}
	public byte[][] getImageList() throws Exception
	{
		byte[][] imageList = new byte[this.images.size()][];
		
		for(int i = 0; i < this.images.size(); i++)
		{
			imageList[i] = convert(this.images.get(i));
		}
		return imageList;
	}
	private byte[] convert(String image) throws Exception
	{
		File in = new File(image);
        InputStream input = new FileInputStream(in);

         byte[] buff = new byte[(int) in.length()];
         int bytesRead = 0;

         ByteArrayOutputStream bao = new ByteArrayOutputStream();
         while((bytesRead = input.read(buff)) != -1) {
            bao.write(buff, 0, bytesRead);
         }
         input.close();
        return bao.toByteArray();
	}
	

}
