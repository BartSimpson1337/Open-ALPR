package main;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import javax.swing.event.ListSelectionEvent;

import webservice.AlprClientRemote;
import camera.CameraParameters;
import request.Data;
import request.Lists;


public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		AlprClientRemote remote = new AlprClientRemote();
			try {
				//System.out.println(remote.register("Diogo", "1994/04/29", 915381423, "dfrr_rodrigues@hotmail.com", "12345"));
				//System.out.println(remote.login("scp@hotmail.com", "12345"));
				//System.out.println(remote.logout(101));
				//System.out.println(remote.myAccount(1).getName());
				//System.out.println(remote.withdraw(1, "100.14"));
				//System.out.println(remote.deposit(1, "1000.15"));
				
				//System.out.println(remote.isAlive());
				
				
				Lists lists = new Lists();
					//lists.addImage("/home/Diogo/Documentos/Projeto EI/openalpr/src/build/Photos/Requests/12.jpg");
					//lists.addImage("/home/Diogo/Documentos/Projeto EI/openalpr/src/build/Photos/Requests/13.jpg");
					//lists.addImage("/home/Diogo/Documentos/Projeto EI/openalpr/src/build/Photos/Requests/14.jpg");
					lists.addImage("/home/Diogo/Documentos/Projeto EI/openalpr/src/build/Photos/Requests/213.jpg");
					lists.addImage("/home/Diogo/Documentos/Projeto EI/openalpr/src/build/Photos/Requests/DSC_0014.JPG");
				CameraParameters cp = new CameraParameters();
					cp.setFocallength(3.57F);
					cp.setSensorHeight(3.45F);
					cp.setSensorWidth(4.45F);
					lists.addParameter(cp);
					lists.addParameter(cp);
			
				
		

					
				Data data = new Data();
					data.setParameters(lists.getListOfCameraParameters());
					data.setPhotos(lists.getImageList());
					
				System.out.println(remote.request(1, 1, data));
				
					
				//System.out.println(remote.addVehicle("4969JX", "Golf", "4", 2003, "cinzento", "diesel", 75, 1422, "arranhado de lado", 1));
				//System.out.println(remote.addAdvertising("2017/04/29", "ferrari", "200.53", "Braga", "farol partido", 1));
				
				//System.out.println(remote.Advertisings().get(0).getTitle());
				
				//System.out.println(remote.myAdvertisings(1).get(0).getTitle());
				//System.out.println(remote.AdvertisingsByLocation("Braga").get(0).getTitle());
				
				//System.out.print(remote.myVehicles(1).get(0).getBrand());
				
				/*
				for(int i = 0; i < remote.getPhotos(2).getPhotos().length; i++)
				{
				File tmp = new File("/home/Diogo/Documentos/Projeto EI/backup class/tmp"+String.valueOf(i)+".jpg");
				   OutputStream out = new BufferedOutputStream(new FileOutputStream(tmp));
				    out.write(remote.getPhotos(2).getPhotos()[i]);
				    out.close();
				}
				*/
					
			//	System.out.println(remote.myRewards(2).get(0).getTitle());
					
				//System.out.println(remote.myId("scp@hotmail.com"));
					
				/*
				for(int i = 0; i < remote.myResults(1).size(); i++)
				{
					File tmp = new File("/home/Diogo/Documentos/Projeto EI/backup class/tmp"+String.valueOf(i)+".jpg");
					   OutputStream out = new BufferedOutputStream(new FileOutputStream(tmp));
					    out.write(remote.myResults(1).get(i).getPhoto());
					    out.close();
				}
				*/
				
				//System.out.println(remote.rmVehicle(3));
				
				/*
				File tmp = new File("/home/Diogo/Documentos/Projeto EI/backup class/tmp"+1+".jpg");
					 OutputStream out = new BufferedOutputStream(new FileOutputStream(tmp));
					  out.write(remote.myAccount(4).getPhoto());
					  out.close();
				*/
				//System.out.println(remote.addUserPhoto(4, listOfImages.getImageList()[0]));
				//System.out.println(remote.rmUserPhoto(4));
						
				//System.out.println(remote.rmResult(101));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

	}
}
