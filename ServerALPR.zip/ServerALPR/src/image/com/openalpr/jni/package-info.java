/**
 * 
 */
/**
 * @author Diogo
 *
 */
package com.openalpr.jni;