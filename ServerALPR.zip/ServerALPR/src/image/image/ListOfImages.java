package image;

import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.lang.reflect.InvocationTargetException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;

import javax.imageio.ImageIO;
import javax.swing.SwingUtilities;

import org.omg.PortableInterceptor.DISCARDING;

import com.drew.imaging.ImageMetadataReader;
import com.drew.imaging.ImageProcessingException;
import com.drew.lang.GeoLocation;
import com.drew.metadata.Metadata;
import com.drew.metadata.exif.GpsDirectory;
import com.openalpr.jni.Alpr;
import com.openalpr.jni.AlprException;
import com.openalpr.jni.AlprPlate;
import com.openalpr.jni.AlprPlateResult;
import com.openalpr.jni.AlprResults;

import models.Send;
import querys.tblSend;
import request.ListOfRequests;
import request.Request;
import request.Result;
import service.CarService;
import service.GeolocationService;
import service.NetworkServices;

public class ListOfImages implements Runnable{

	private LinkedBlockingQueue<Request> requestList;
	private LinkedBlockingQueue<Request> executedRequestList;
	static int index = 0; //Contador estatico, que vai ser usado por ambas as threads.
	
	public ListOfImages(LinkedBlockingQueue<Request> requestList, LinkedBlockingQueue<Request> executedRequestList) {
		// TODO Auto-generated constructor stub
		this.requestList = requestList;
		this.executedRequestList = executedRequestList;
		
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		while(true)
		{
	
			try {
		
				Request rq = this.requestList.take();
				
				for(int i = 0; i < rq.getData().getPhotos().length; i++)
				{
					MetaData imagedata = getImage(rq.getData().getPhotos()[i]);
						
					if(imagedata != null)
					{
						imagedata.setIndex(i);
						Image img = new Image(imagedata.getImagePath());	
						
						if(!img.alpr().getPlates().isEmpty())
						{
							for(AlprPlateResult result : img.alpr().getPlates())
							{
							     for (AlprPlate plate : result.getTopNPlates())
							     { 		
							    	 	if(plate.getCharacters().length() == 6)
							    	 	{    
							    	 		
							    		 	SwingUtilities.invokeAndWait(new Runnable(){
								    		 		//Runnable runnable = new Runnable(){
								    		 			@Override
														public void run() {
									            	  		
								    		 				System.out.println(plate.getCharacters());
								    		 				Result rs = new Result();
									            	        
									            	  		increment(); //Increment counter to previos ip rotation
									            	  			try {
									            	  				
													            		//Code to get ip address
													            		URL whatismyip = new URL("http://checkip.amazonaws.com");
																		BufferedReader in = new BufferedReader(new InputStreamReader(
																				           	whatismyip.openStream()));
																		String ip = in.readLine(); //you get the IP as a String
																		System.out.println(ip);  
													            		  
													          			CarService cs = new CarService();
														          			cs.setPlate(new StringBuilder(plate.getCharacters()).insert(2, '-').insert(5, '-').toString());
														          			cs.Connection();
													          		
						
														          		rs.setImagePath(imagedata.getImagePath());
															            rs.setPlate(plate.getCharacters());
															            rs.setConfidencePlate(plate.getOverallConfidence());
															            rs.setProcessingTime(result.getProcessingTimeMs());
													          			
														          		rs.setBrand(cs.getBrand());
														          		rs.setModel(cs.getModel());
														          		rs.setYear(cs.getYear());
														          		rs.setFuel(cs.getFuel());
														          		rs.setColor(cs.getColor());
														          		rs.setType(cs.getType());
														          		rs.setCC(cs.getCC());
														          		rs.setHP(cs.getHP());
									
														          		rs.setGeolocation(imagedata.getGeolocation());
																        rs.setLatitude(imagedata.getLatitude());
																        rs.setLongitude(imagedata.getLongitude());
														          		rs.setDate(imagedata.getDate());
														          		rs.setTime(imagedata.getTime());
														          		
														          		
														          		RegistrationPlateDimensions registrationPlateDimensions = new RegistrationPlateDimensions();
														          			registrationPlateDimensions.addCoordinate(result.getPlatePoints().get(0).getX(), result.getPlatePoints().get(0).getY());
														          			registrationPlateDimensions.addCoordinate(result.getPlatePoints().get(1).getX(), result.getPlatePoints().get(1).getY());
														          			registrationPlateDimensions.addCoordinate(result.getPlatePoints().get(2).getX(), result.getPlatePoints().get(2).getY());
														          			registrationPlateDimensions.addCoordinate(result.getPlatePoints().get(3).getX(), result.getPlatePoints().get(3).getY());
														          			registrationPlateDimensions.setDimensions();
														          			
														          		if(rq.getRequestType() == 0)
														            	{
														            		new RegistrationPlateCover(imagedata.getImagePath(), registrationPlateDimensions);
														            	     
														            	}
														          		else
														          		{
														          			new RegistrationPlateDistances(registrationPlateDimensions, rq.getData().getParameters().get(imagedata.getIndex()), imagedata);
														          		}	
														                rq.setResult(rs); 

												          		} catch (Exception e) {
												          			e.printStackTrace();
												          		}
														}
								    		 	});
								         }
							     	} 
							   }
						  }
						  else
						  {
							  File tmp = new File(imagedata.getImagePath());
							  tmp.delete();
						  }
					  }
				}
				rq.setExecutionDate();
				rq.setExecutionTime();
				this.executedRequestList.offer(rq);
			
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	static synchronized void increment()	//Método que vai fazer o incremento.
	{
		index++;

        if(index % 4 == 0)	//Após 4 pedidos no servidor, o ip proxy da rede tor é alterado.
        {
      	  	NetworkServices.restartTorService(); 	//Faz restart no serviço tor, para alterar o ip.
        }
	}
	synchronized MetaData getImage(byte[] image) 
	{
		MetaData imagedata = null;
		try {
		   
			Metadata metadata = ImageMetadataReader.readMetadata(new BufferedInputStream(new ByteArrayInputStream(image)), image.length);
			imagedata = new MetaData(metadata);
			
			if(imagedata.getLatitude() != 0 && imagedata.getLongitude() != 0)
			{
				imagedata.getExif();
				
				boolean state = true;
				File tmp = null;
				while(state)
				{
					tmp = new File("/home/Diogo/workspace/ProjetoEI_DiogoRodrigues/ServerALPR/Temporary/tmp"+Long.toHexString(Double.doubleToLongBits(Math.random()))+".jpg");
					if(!tmp.exists())
					{
						OutputStream out = new BufferedOutputStream(new FileOutputStream(tmp));
						    out.write(image);
						    out.close();
						if(tmp.exists())
						{
						    imagedata.setImagePath(tmp.getAbsolutePath());
							state = false;
						}
					}
				}
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return imagedata;
	}
}


