package image;


import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.SwingUtilities;


public class RegistrationPlateCover {
	
	private int x;
	private int y;
	private int width;
	private int height;
	private String image;

	public RegistrationPlateCover(String image, RegistrationPlateDimensions registrationPlateDimensions)
	{
		this.image = image;
		this.x = registrationPlateDimensions.getX();
		this.y = registrationPlateDimensions.getY();
		this.width = registrationPlateDimensions.getWidth();
		this.height = registrationPlateDimensions.getHeight();
		draw();
		
	}
	private void draw()
	{
		BufferedImage imagewrite, imageread;
		try {
			imageread = ImageIO.read(new File(image));
			imagewrite = new BufferedImage(imageread.getWidth(), imageread.getHeight(), BufferedImage.TYPE_INT_RGB);
			imagewrite = imageread;
				
			 // Create a graphics which can be used to draw into the buffered image
			 Graphics2D g2d = imagewrite.createGraphics();

			 // fill all the image with white
			 g2d.setColor(Color.WHITE);
			 g2d.fillRect(this.x, this.y, this.width, this.height);

			 // Disposes of this graphics context and releases any system resources that it is using. 
			 g2d.dispose();

			 // Save as PNG
			 File file = new File(this.image);
		     ImageIO.write(imagewrite, "jpg", file);
			
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
}