package image;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

import javax.imageio.ImageIO;

import image.RegistrationPlateCoordinates;


public class RegistrationPlateDistances {

	private CameraParameters cameraParameters;
	private RegistrationPlateDimensions registrationPlateDimensions;
	private MetaData imagedata;
	private Color color;
	
	
	public RegistrationPlateDistances(RegistrationPlateDimensions registrationPlateDimensions, CameraParameters cameraParameters, MetaData imagedata)
	{
		this.registrationPlateDimensions = registrationPlateDimensions;
		this.cameraParameters = cameraParameters;
		this.imagedata = imagedata;
		
		draw(convertUnits(getDistance()));
	}
	
	private BigDecimal getDistance()
	{
		int imageWidth = Integer.valueOf(imagedata.getWidth().replaceAll("[^0-9]", ""));
		int imageHeight = Integer.valueOf(imagedata.getHeight().replaceAll("[^0-9]", ""));
	
		//check formula type
		if(imageWidth > imageHeight)
		{
			return (new BigDecimal(String.valueOf(this.cameraParameters.getFocallength())).multiply(new BigDecimal("520")).multiply(new BigDecimal(String.valueOf(imageWidth)))).divide(new BigDecimal(String.valueOf(registrationPlateDimensions.getWidth())).multiply(new BigDecimal(String.valueOf(cameraParameters.getSensorWidth()))), 2, RoundingMode.HALF_UP);
		}
		else
		{
			return (new BigDecimal(String.valueOf(this.cameraParameters.getFocallength())).multiply(new BigDecimal("110")).multiply(new BigDecimal(String.valueOf(imageHeight)))).divide(new BigDecimal(String.valueOf(registrationPlateDimensions.getHeight())).multiply(new BigDecimal(String.valueOf(cameraParameters.getSensorHeight()))), 2, RoundingMode.HALF_UP);
		}
	}
	
	private String convertUnits(BigDecimal distance)
	{
		if(distance.compareTo(new BigDecimal("1000")) == 0 || distance.compareTo(new BigDecimal("1000")) == 1) //if distance is bigger then 1 meter
		{
			this.color = Color.RED;
			return String.valueOf(distance.multiply(new BigDecimal("0.001")).setScale(2, RoundingMode.HALF_UP))+" m";
		}
		else
		{
			this.color = Color.GREEN;
			return String.valueOf(distance.multiply(new BigDecimal("0.1")).setScale(2, RoundingMode.HALF_UP))+" cm";
		}
	}
	
	private void draw(String distance)
	{
		BufferedImage imagewrite, imageread;
		try {
			imageread = ImageIO.read(new File(imagedata.getImagePath()));
			imagewrite = new BufferedImage(imageread.getWidth(), imageread.getHeight(), BufferedImage.TYPE_INT_RGB);
			imagewrite = imageread;
				
			 // Create a graphics which can be used to draw into the buffered image
			 Graphics2D g2d = imagewrite.createGraphics();

			 // fill all the image with white
			 g2d.setColor(this.color);
			 g2d.setStroke(new BasicStroke(20));
			 g2d.drawRect(registrationPlateDimensions.getX(), registrationPlateDimensions.getY(), registrationPlateDimensions.getWidth(), registrationPlateDimensions.getHeight());
		

			 g2d.setFont(new Font ("Courier New", 1, 100)); 
			 g2d.drawString(distance, registrationPlateDimensions.getX(), registrationPlateDimensions.getY()+registrationPlateDimensions.getHeight()+100);
			 
			 
			 // Disposes of this graphics context and releases any system resources that it is using. 
			 g2d.dispose();

			 // Save as PNG
			 File file = new File(this.imagedata.getImagePath());
		     ImageIO.write(imagewrite, "jpg", file);
		
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
	}


	
	
}
