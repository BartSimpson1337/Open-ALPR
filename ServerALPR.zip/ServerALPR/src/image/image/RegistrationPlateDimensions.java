package image;

import java.util.ArrayList;
import java.util.List;
import image.RegistrationPlateCoordinates;

public class RegistrationPlateDimensions {

	private int x;
	private int y;
	private int width;
	private int height;
	private List<RegistrationPlateCoordinates> listOfcoordinates = new ArrayList<RegistrationPlateCoordinates>();
	
	
	public RegistrationPlateDimensions()
	{
	}
	
	public void addCoordinate(int x, int y)
	{
		this.listOfcoordinates.add(new RegistrationPlateCoordinates(x, y));
	}
	public void setDimensions()
	{
		setX(returnX());
		setY(returnY());
		setWidth(returnWidth());
		setHeight(returnHeight());
	}
	
	public int returnX() {
		
		int min = this.listOfcoordinates.get(0).x;
		for(int i = 0; i < this.listOfcoordinates.size() ;i++)
	    {
	        if(min > this.listOfcoordinates.get(i).x)
	        {
	            min = this.listOfcoordinates.get(i).x;
	        }
	    }
		
		return min;
	}

	public int returnY() {
		
		int min = this.listOfcoordinates.get(0).y;
		for(int i = 0; i < this.listOfcoordinates.size() ;i++)
		    {
		        if(min > this.listOfcoordinates.get(i).y)
		        {
		            min = this.listOfcoordinates.get(i).y;
		        }
		    }
		return min;
	}

	public int returnWidth() {
		
		int max = 0;
		for(int i = 0; i < this.listOfcoordinates.size();i++)
		{
			   if(max < this.listOfcoordinates.get(i).x)
		       {
		            max = this.listOfcoordinates.get(i).x;
		       }
		}
		return max-this.x;
	}

	public int returnHeight() {
		
		int max = 0;
		for(int i = 0; i < this.listOfcoordinates.size();i++)
		{
			   if(max < this.listOfcoordinates.get(i).y)
		       {
		            max = this.listOfcoordinates.get(i).y;
		       }			 
		}
		return max-this.y;
	}

	public int getX()
	{
		return this.x;
	}
	public int getY()
	{
		return this.y;
	}
	public int getWidth()
	{
		return this.width;
	}
	public int getHeight()
	{
		return this.height;
	}
	
	
	public void setX(int x)
	{
		this.x = x;
	}
	public void setY(int y)
	{
		this.y = y;
	}
	public void setWidth(int width)
	{
		this.width = width;
	}
	public void setHeight(int height)
	{
		this.height = height;
	}
	
}
