package image;


import java.util.concurrent.LinkedBlockingQueue;

import com.openalpr.jni.Alpr;
import com.openalpr.jni.AlprException;
import com.openalpr.jni.AlprPlate;
import com.openalpr.jni.AlprPlateResult;
import com.openalpr.jni.AlprRegionOfInterest;
import com.openalpr.jni.AlprResults;


public class Image{

	private static final Alpr alpr = new Alpr("eu", "/home/Diogo/Documentos/Projeto EI/openalpr/src/build/config/openalpr.conf", "/home/Diogo/Documentos/Projeto EI/openalpr/runtime_data");
	private String image;
	private AlprResults results;
	
	public Image(String image)
	{
		this.image = image;
	}
	public AlprResults alpr()
	{
		this.alpr.setTopN(1);
		synchronized (this.alpr) {
			try {
				this.results =  this.alpr.recognize(image);
			} catch (AlprException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return this.results;
		
	}
}
