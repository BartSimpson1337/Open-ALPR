package image;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.SwingUtilities;

import com.drew.imaging.ImageMetadataReader;
import com.drew.imaging.ImageProcessingException;
import com.drew.lang.GeoLocation;
import com.drew.metadata.Directory;
import com.drew.metadata.Metadata;
import com.drew.metadata.Tag;
import com.drew.metadata.exif.ExifImageDirectory;
import com.drew.metadata.exif.GpsDirectory;

import service.GeolocationService;

public class MetaData {

	private int index;
	private String imagePath; //path to image.
	private String compressionType;
	private String make;
	private String model;
	private String software;
	private String flash;
	private String focalLength;
	private String colorSpace;
	private String fileSource;
	private String digitalZoom;
	private String fileName;
	private String fileSize;
	private String fileModifiedDate;
	private String height;
	private String width;
	private double latitude;
	private double longitude;
	private String geolocation;
	private String date;
	private String time;
	private int orientation;
	private Metadata metadata;

		
	public MetaData(Metadata metadata)
	{
		this.metadata = metadata;
		getCoordinates();
	
	}
	private void getCoordinates()
	{
		try
		{
		GpsDirectory gpsDirectory = metadata.getFirstDirectoryOfType(GpsDirectory.class); //Exif GPS latitute and longiture in decimal.
		GeoLocation location = gpsDirectory.getGeoLocation();
			this.latitude = location.getLatitude();
			this.longitude = location.getLongitude();
		}
		catch(Exception e)
		{
		}
		
	}
	public void getExif()
	{
		try {
				  for (Directory directory : this.metadata.getDirectories())
				  {
			            for (Tag tag : directory.getTags())
			            {	
			            	if(tag.getTagName().equalsIgnoreCase("Compression Type"))
			            	{
			            		this.compressionType = tag.getDescription();
			            	}
			            	else if(tag.getTagName().equalsIgnoreCase("Image Height"))
			            	{
			            		this.height = tag.getDescription();
			            	}
			            	else if(tag.getTagName().equalsIgnoreCase("Image Width"))
			            	{
			            		this.width = tag.getDescription();
			            	}
			            	else if(tag.getTagName().equalsIgnoreCase("Make"))
			            	{
			            		this.make = tag.getDescription();
			            	}
			            	else if(tag.getTagName().equalsIgnoreCase("Model"))
			            	{
			            		this.model = tag.getDescription();
			            	}
			            	else if(tag.getTagName().equalsIgnoreCase("Software"))
			            	{
			            		this.software = tag.getDescription();
			            	}
			            	else if(tag.getTagName().equalsIgnoreCase("Date/Time"))
			            	{

			            		formatDate(tag.getDescription());
			            	}
			            	else if(tag.getTagName().equalsIgnoreCase("Flash"))
			            	{
			            		this.flash = tag.getDescription();
			            	}
			              	else if(tag.getTagName().equalsIgnoreCase("Focal Length"))
			            	{
			            		this.focalLength = tag.getDescription();
			            	}
			              	else if(tag.getTagName().equalsIgnoreCase("Color Space"))
			            	{
			            		this.colorSpace = tag.getDescription();
			            	}
			              	else if(tag.getTagName().equalsIgnoreCase("File Source"))
			            	{
			            		this.fileSource = tag.getDescription();
			            	}
			              	else if(tag.getTagName().equalsIgnoreCase("Digital Zoom Ratio"))
			            	{
			            		this.digitalZoom = tag.getDescription();
			            	}
			              	else if(tag.getTagName().equalsIgnoreCase("File Name"))
			            	{
			            		this.fileName = tag.getDescription();
			            	}
			              	else if(tag.getTagName().equalsIgnoreCase("File Size"))
			            	{
			            		this.fileSize = tag.getDescription();
			            	}
			              	else if(tag.getTagName().equalsIgnoreCase("File Modified Date"))
			            	{
			            		this.fileModifiedDate = tag.getDescription();
			            	}
			            }
			            for (String error : directory.getErrors())
			            {
			                System.err.println("ERROR: " + error);
			            }  
			     }
		} catch (Exception e) {
			System.out.println("Error extracting metadata from this picture!");
		}
	}

	public void formatDate(String date)
	{
		String str = date;
		String[] splitStr = str.split("\\s+");
		
		this.date = splitStr[0].replaceAll(":", "/");
		this.time = splitStr[1];
	}
	
	public String getGeolocation()
	{
			return this.geolocation = new GeolocationService(this.latitude, this.longitude).getGeolocation();
	}
	
	public String getImagePath()
	{
		return this.imagePath;
	}
	public String getCompressionType()
	{
		return this.compressionType;
	}
	public String getMake()
	{
		return this.make;
	}
	public String getModel()
	{
		return this.model;
	}
	public String getSoftware()
	{
		return this.software;
	}
	public String getDate()
	{
		return this.date;
	}
	public String getTime()
	{
		return this.time;
	}
	public String getFlash()
	{
		return this.flash;
	}
	public String getFocalLengh()
	{
		return this.focalLength;
	}
	public String getColorSpace()
	{
		return this.colorSpace;
	}
	public String getFileSource()
	{
		return this.fileSource;
	}
	public String getDigitalZoom()
	{
		return this.digitalZoom;
	}
	public String getFileName()
	{
		return this.fileName;
	}
	public String getFileSize()
	{
		return this.fileSize;
	}
	public String getFileModifiedDate()
	{
		return this.fileModifiedDate;
	}
	public String getHeight()
	{
		return this.height;
	}
	public String getWidth()
	{
		return this.width;
	}
	public double getLatitude()
	{
		return this.latitude;
	}
	public double getLongitude()
	{
		return this.longitude;
	}
	public void setImagePath(String imagepath)
	{
		this.imagePath = imagepath;
	}
	public int getIndex() {
		return index;
	}
	public void setIndex(int index) {
		this.index = index;
	}
}
