package image;

public class RegistrationPlateCoordinates {
	
	
	public int x;
	public int y;
	
	public RegistrationPlateCoordinates(int x, int y)
	{
		this.x = x;
		this.y = y;
	}
	
	

	
}
