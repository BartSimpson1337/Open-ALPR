package webservice;


import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.sql.Blob;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import javax.enterprise.context.ConversationScoped;
import javax.inject.Inject;
import javax.print.attribute.standard.Media;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.codehaus.jackson.map.ObjectMapper;
//import org.codehaus.jackson.map.JsonMappingException;
//import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import containers.AdvertisingsContainer;
import containers.CashContainer;
import containers.ClientContainer;
import containers.LoginContainer;
import containers.PhotographsContainer;
import containers.RegisterContainer;
import containers.RequestContainer;
import containers.ResultsContainer;
import containers.VehiclesContainer;
import models.Advertising;
import models.Client;
import models.PhotographyClient;
import models.PhotographyData;
import models.PhotographyVehicle;
import models.Vehicle;
import querys.tblAdvertising;
import querys.tblClient;
import querys.tblPayment;
import querys.tblPhotography;
import querys.tblPhotographyClient;
import querys.tblPhotographyData;
import querys.tblPhotographyVehicle;
import querys.tblVehicle;
import request.ListOfRequests;
import request.Request;

@Path("WebService")
public class AlprServerRemote implements AlprServerInterface, HttpHandler {

	@Inject
	private ListOfRequests listofrequests;
	private static List<String> tokens = new ArrayList<String>();
	
	public AlprServerRemote()
	{
	
	}
	
	@GET
	@Path("testConnection")
	public Response isAlive()
	{
		return Response.ok().build();
	}
	

	@Override
	@POST
	@Path("method_1")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.TEXT_PLAIN)
	public boolean login(@FormParam("param")String json) throws Exception {
		
		ObjectMapper mapper = new ObjectMapper();
		LoginContainer loginContainer = mapper.readValue(json, new TypeReference<LoginContainer>(){});
		
		if(userValidation(loginContainer.getToken()))
		{
			tblClient tc = new tblClient();
				boolean state =	tc.login(loginContainer.getEmail(), loginContainer.getPassword());
			tc.closeConnection();
			tokens.remove(loginContainer.getToken());
			return state;
		}
		return false;
	}
	
	@Override
	@POST
	@Path("method_2")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.TEXT_PLAIN)
	public boolean logout(@FormParam("param")String token, @FormParam("param2")int id) throws Exception {
		// TODO Auto-generated method stub
		if(userValidation(token))
		{
			tblClient tc = new tblClient();
				boolean state = tc.logout(id);
			tc.closeConnection();		
			tokens.remove(token);
			return state;
		}
		return false;
	}
	
	
	@Override
	@POST
	@Path("method_3")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.TEXT_PLAIN)
	public boolean register(@FormParam("param")String json) throws Exception {
		// TODO Auto-generated method stub
		ObjectMapper mapper = new ObjectMapper();
		RegisterContainer registerContainer = mapper.readValue(json, new TypeReference<RegisterContainer>(){});
		
		if(userValidation(registerContainer.getToken()))
		{
			boolean state = false;
			
			Client client = new Client();
				client.setName(registerContainer.getName());
				client.setBirthDate(registerContainer.getBirth_date());
				client.setContact(registerContainer.getContact());
				client.setEmail(registerContainer.getEmail());
				client.setPassword(registerContainer.getPassword());
				client.setAccountBalance(new BigDecimal("0"));
			
				tblClient tc = new tblClient();
					ResultSet rs = tc.checkUnique(registerContainer.getEmail());
						rs.next();
						if(rs.getInt(1) == 0)
						{
							tc.insert(client);
							state = true;
						}
						else
						{
							state = false;
						}
					rs.close();	
				tc.closeConnection();
			tokens.remove(registerContainer.getToken());
			return state;
		}
		return false;
	}
	
	@Override
	@POST
	@Path("method_4")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.APPLICATION_JSON)
	public ClientContainer myAccount(@FormParam("param")String token, @FormParam("param2")int id) throws Exception {
		
		if(userValidation(token))
		{
			ClientContainer clientContainer = new ClientContainer();
			tblClient tc = new tblClient();
				ResultSet rs = tc.selectBy(id);
				while(rs.next())
				{
						clientContainer.setId(rs.getInt(1));
						clientContainer.setName(rs.getString(2));
						clientContainer.setBirth_date(rs.getString(3).replaceAll("-", "/"));
						clientContainer.setContact(rs.getInt(4));
						clientContainer.setEmail(rs.getString(5));
						clientContainer.setPassword(rs.getString(6));
						clientContainer.setAccount_balance(new BigDecimal(rs.getString(7)));
					
						tblPhotographyClient tpc = new tblPhotographyClient();
							ResultSet rs2 = tpc.selectBy(rs.getInt(1));
								while(rs2.next())
								{
									Blob photoBlob = rs2.getBlob(2);
									byte[] photoBytes = photoBlob.getBytes(1, (int) photoBlob.length());
									clientContainer.setPhoto(photoBytes);
								}
							rs2.close();
						tpc.closeConnection();
						
				}
				rs.close();
			tc.closeConnection();
			tokens.remove(token);
			return clientContainer;
		}
		return null;
	}
	
	@Override
	@POST
	@Path("method_5")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.TEXT_PLAIN)
	public boolean withdraw(@FormParam("param")String json) throws Exception {
		// TODO Auto-generated method stub
		ObjectMapper mapper = new ObjectMapper();
		CashContainer cashContainer = mapper.readValue(json, new TypeReference<CashContainer>(){});
		
		if(userValidation(cashContainer.getToken()))
		{
			boolean state = false;
			BigDecimal withdrawvalue = new BigDecimal(cashContainer.getValue());
			try 
			{
			tblClient tc = new tblClient();
				ResultSet rs = tc.selectBy(cashContainer.getId());
					while(rs.next())
					{
						BigDecimal accountBalance = new BigDecimal(rs.getString(7));
						if(accountBalance.subtract(withdrawvalue).compareTo(BigDecimal.ZERO) >= 0)
						{
							state = true;
							tc.updateAccountBalance(cashContainer.getId(), accountBalance.subtract(withdrawvalue));
						}
					}
				rs.close();
			tc.closeConnection();
			}
			catch(SQLException e)
			{
				state = false;
			}
			tokens.remove(cashContainer.getToken());
			return state;
		}
		return false;
	}

	@Override
	@POST
	@Path("method_6")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.TEXT_PLAIN)
	public boolean deposit(@FormParam("param") String json) throws Exception {
		// TODO Auto-generated method stub
		ObjectMapper mapper = new ObjectMapper();
		CashContainer cashContainer = mapper.readValue(json, new TypeReference<CashContainer>(){});
		
		if(userValidation(cashContainer.getToken()))
		{
			boolean state = false;
			BigDecimal deposit = new BigDecimal(cashContainer.getValue());
			try
			{
				tblClient tc = new tblClient();
				ResultSet rs = tc.selectBy(cashContainer.getId());
					while(rs.next())
					{	
						
						BigDecimal accountBalance = new BigDecimal(rs.getString(7));
						tc.updateAccountBalance(cashContainer.getId(), accountBalance.add(deposit));
						state = true;
					}
				rs.close();
				tc.closeConnection();
			}
			catch(SQLException e)
			{
					state = false;
			}
			tokens.remove(cashContainer.getToken());
			return state;
		}
		return false;
	}

	@Override
	@POST
	@Path("method_7")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.TEXT_PLAIN)
	public boolean request(@FormParam("param")String json) throws Exception
	{
		ObjectMapper mapper = new ObjectMapper();
		RequestContainer requestContainer = mapper.readValue(json, new TypeReference<RequestContainer>(){});
	
		if(userValidation(requestContainer.getToken()))
		{
			// TODO Auto-generated method stub
			boolean state = false;
			Request request = new request.Request(requestContainer.getClientid(), requestContainer.getType());
				request.setData(requestContainer.getData());
				
			try
			{
				this.listofrequests.offer(request);
				state = true;
			}
			catch(Exception e)
			{
			}
			tokens.remove(requestContainer.getToken());
			return state;
		}
		return false;
	}

	@Override
	@POST
	@Path("method_8")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.TEXT_PLAIN)
	public boolean addAdvertising(@FormParam("param")String json) throws Exception {
		// TODO Auto-generated method stub
		ObjectMapper mapper = new ObjectMapper();
		AdvertisingsContainer advertisingContainer = mapper.readValue(json, new TypeReference<AdvertisingsContainer>(){});
	
		if(userValidation(advertisingContainer.getToken()))
		{
			boolean state = true;
			Advertising advertising = new Advertising();
			advertising.setDate(advertisingContainer.getDate());
			advertising.setTitle(advertisingContainer.getTitle());
			advertising.setReward(new BigDecimal(advertisingContainer.getReward()));
			advertising.setLocalization(advertisingContainer.getLocalization());
			advertising.setDescription(advertisingContainer.getDescription());
			advertising.setVehicleId(advertisingContainer.getVehicleid());
			
			tblAdvertising ta = new tblAdvertising();
				ResultSet rs = ta.selectActiveAdvertisings();
					while(rs.next())
					{
						if(rs.getInt(8) == advertisingContainer.getVehicleid())
						{
							state = false;
						}
					}
				rs.close();
				if(state == true)
				{
					ta.insert(advertising);
				}
				
			ta.closeConnection();
			tokens.remove(advertisingContainer.getToken());
			return state;
		}
		return false;
	}

	@Override
	@POST
	@Path("method_9")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.APPLICATION_JSON)
	public List<AdvertisingsContainer> Advertisings(@FormParam("param")String token) throws Exception {
		// TODO Auto-generated method stub
		if(userValidation(token))
		{
			List<AdvertisingsContainer> advertisingsContainers = new ArrayList<AdvertisingsContainer>();
			tblAdvertising ta = new tblAdvertising();
				ResultSet rs = ta.selectActiveAdvertisings();
					while(rs.next())
					{
						AdvertisingsContainer advertisingsContainer = new AdvertisingsContainer();
						advertisingsContainer.setId(rs.getInt(1));
						advertisingsContainer.setDate(rs.getString(2).replaceAll("-", "/"));
						advertisingsContainer.setTitle(rs.getString(3));
						advertisingsContainer.setReward(rs.getString(4));
						advertisingsContainer.setLocalization(rs.getString(5));
						advertisingsContainer.setDescription(rs.getString(6));
						advertisingsContainer.setVehicleid(rs.getInt(8));
						advertisingsContainers.add(advertisingsContainer);	
					}
				rs.close();
			ta.closeConnection();
			tokens.remove(token);
			return advertisingsContainers;
		}
		return null;
	}

	

	@Override
	@POST
	@Path("method_10")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.TEXT_PLAIN)
	public boolean addVehicle(@FormParam("param")String json) throws Exception {
		// TODO Auto-generated method stub
		ObjectMapper mapper = new ObjectMapper();
		VehiclesContainer vehiclesContainer = mapper.readValue(json, new TypeReference<VehiclesContainer>(){});
		
		if(userValidation(vehiclesContainer.getToken()))
		{
				boolean state = false;
				Vehicle vehicle = new Vehicle();
				vehicle.setPlate(vehiclesContainer.getPlate());
				vehicle.setBrand(vehiclesContainer.getBrand());
				vehicle.setModel(vehiclesContainer.getModel());
				vehicle.setRegistrationYear(vehiclesContainer.getRegistration_year());
				vehicle.setColor(vehiclesContainer.getColor());
				vehicle.setFuel(vehiclesContainer.getFuel());
				vehicle.setHP(vehiclesContainer.getHp());
				vehicle.setCC(vehiclesContainer.getCc());
				vehicle.setDescription(vehiclesContainer.getDescription());
				vehicle.setClientId(vehiclesContainer.getClientid());
				tblVehicle tv = new tblVehicle();
					ResultSet rs = tv.checkUnique(vehiclesContainer.getPlate());
						rs.next();
						if(rs.getInt(1) == 0)
						{
							tv.insert(vehicle);
							state = true;
						}
						else
						{
							ResultSet rs2 = tv.selectClient_v2(vehiclesContainer.getClientid());
							while(rs2.next())
							{
								if(rs2.getString(2).equalsIgnoreCase(vehiclesContainer.getPlate()))
								{
									if(rs2.getBoolean(12) == false)
									{
										tv.activateVehicle(rs2.getInt(1));
									}
								}
							}
							rs2.close();
							state = false;
						}
					rs.close();
				tv.closeConnection();
				tokens.remove(vehiclesContainer.getToken());
				return state;
			}
		return false;
	}

	@Override
	@POST
	@Path("method_11")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.APPLICATION_JSON)
	public List<AdvertisingsContainer> myAdvertisings(@FormParam("param")String token, @FormParam("param2")int clientid) throws Exception {
		// TODO Auto-generated method stub
		if(userValidation(token))
		{
			List<AdvertisingsContainer> advertisingsContainers = new ArrayList<AdvertisingsContainer>();
			tblAdvertising ta = new tblAdvertising();
				ResultSet rs = ta.selectAdvertisingClient(clientid);
					while(rs.next())
					{
						AdvertisingsContainer advertisingsContainer = new AdvertisingsContainer();
						advertisingsContainer.setId(rs.getInt(1));
						advertisingsContainer.setDate(rs.getString(2).replaceAll("-", "/"));
						advertisingsContainer.setTitle(rs.getString(3));
						advertisingsContainer.setReward(rs.getString(4));
						advertisingsContainer.setLocalization(rs.getString(5));
						advertisingsContainer.setDescription(rs.getString(6));
						advertisingsContainer.setVehicleid(rs.getInt(8));
						advertisingsContainers.add(advertisingsContainer);	
					}
				rs.close();
			ta.closeConnection();
			tokens.remove(token);
			return advertisingsContainers;
		}
		return null;
	}

	@Override
	@POST
	@Path("method_12")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.APPLICATION_JSON)
	public List<AdvertisingsContainer> AdvertisingsByLocation(@FormParam("param")String token, @FormParam("param2")String location) throws Exception {
		// TODO Auto-generated method stub
		if(userValidation(token))
		{
			List<AdvertisingsContainer> advertisingsContainers = new ArrayList<AdvertisingsContainer>();
			tblAdvertising ta = new tblAdvertising();
				ResultSet rs = ta.selectAll();
					while(rs.next())
					{
						if(rs.getString(5).equalsIgnoreCase(location))
						{
							AdvertisingsContainer advertisingsContainer = new AdvertisingsContainer();
							advertisingsContainer.setId(rs.getInt(1));
							advertisingsContainer.setDate(rs.getString(2).replaceAll("-", "/"));
							advertisingsContainer.setTitle(rs.getString(3));
							advertisingsContainer.setReward(rs.getString(4));
							advertisingsContainer.setLocalization(rs.getString(5));
							advertisingsContainer.setDescription(rs.getString(6));
							advertisingsContainer.setVehicleid(rs.getInt(8));
							advertisingsContainers.add(advertisingsContainer);	
				
						}
					}
				rs.close();
			ta.closeConnection();
			tokens.remove(token);
			return advertisingsContainers;
		}
		return null;
	}

	@Override
	@POST
	@Path("method_13")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.APPLICATION_JSON)
	public List<VehiclesContainer> myVehicles(@FormParam("param")String token, @FormParam("param2")int clientid) throws Exception {
		// TODO Auto-generated method stub
		if(userValidation(token))
		{
			List<VehiclesContainer> vehiclesContainers = new ArrayList<VehiclesContainer>();
			tblVehicle tv = new tblVehicle();
				ResultSet rs = tv.selectClient(clientid);
					while(rs.next())
					{
						VehiclesContainer vehiclesContainer = new VehiclesContainer();
						vehiclesContainer.setId(rs.getInt(1));
						vehiclesContainer.setPlate(rs.getString(2));
						vehiclesContainer.setBrand(rs.getString(3));
						vehiclesContainer.setModel(rs.getString(4));
						vehiclesContainer.setRegistration_year(rs.getInt(5));
						vehiclesContainer.setColor(rs.getString(6));
						vehiclesContainer.setFuel(rs.getString(7));
						vehiclesContainer.setHp(rs.getInt(8));
						vehiclesContainer.setCc(rs.getInt(9));
						vehiclesContainer.setDescription(rs.getString(10));
						vehiclesContainer.setClientid(rs.getInt(11));
						vehiclesContainers.add(vehiclesContainer);
					}
				rs.close();
			tv.closeConnection();
			tokens.remove(token);
			return vehiclesContainers;
		}
		return null;
	}

	@Override
	@POST
	@Path("method_14")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.APPLICATION_JSON)
	public List<ResultsContainer> myResults(@FormParam("param")String token, @FormParam("param2")int clientid) throws Exception {
		// TODO Auto-generated method stub
		if(userValidation(token))
		{
			List<ResultsContainer> resultsContainers = new ArrayList<ResultsContainer>();
			tblPhotographyData tpd = new tblPhotographyData();
				ResultSet rs = tpd.selectPhotographyDataClient(clientid);
					while(rs.next())
					{
						ResultsContainer resultsContainer = new ResultsContainer();
						resultsContainer.setId(rs.getInt(1));
						resultsContainer.setDate(rs.getString(2).replaceAll("-", "/"));
						resultsContainer.setTime(rs.getString(3));
						resultsContainer.setGeolocation(rs.getString(4));
						resultsContainer.setLatitude(rs.getDouble(5));
						resultsContainer.setLongitude(rs.getDouble(6));
						resultsContainer.setPlate(rs.getString(7));
						resultsContainer.setConfidence(rs.getFloat(8));
						resultsContainer.setBrand(rs.getString(9));
						resultsContainer.setModel(rs.getString(10));
						resultsContainer.setRegistration_year(rs.getInt(11));
						resultsContainer.setColor(rs.getString(12));
						resultsContainer.setFuel(rs.getString(13));
						resultsContainer.setHp(rs.getInt(14));
						resultsContainer.setCc(rs.getInt(15));
						Blob photoBlob = rs.getBlob(17);
						byte[] photoBytes = photoBlob.getBytes(1, (int) photoBlob.length());
						resultsContainer.setPhoto(photoBytes);
						resultsContainers.add(resultsContainer);
					}
				rs.close();
			tpd.closeConnection();
			tokens.remove(token);
			return resultsContainers;
		}
		return null;
	}

	@Override
	@POST
	@Path("method_15")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.APPLICATION_JSON)
	public List<AdvertisingsContainer> myRewards(@FormParam("param")String token, @FormParam("param2")int clientid) throws Exception {
		// TODO Auto-generated method stub
		if(userValidation(token))
		{
			List<AdvertisingsContainer> advertisingsContainers = new ArrayList<AdvertisingsContainer>();
				tblPayment tp = new tblPayment();
				tblAdvertising ta = new tblAdvertising();
					ResultSet rs = tp.selectPaymentClient(clientid);
					while(rs.next())
					{
						ResultSet rs2 = ta.selectBy(rs.getInt(3));
						
						while(rs2.next())
						{
							AdvertisingsContainer advertisingsContainer = new AdvertisingsContainer();
							advertisingsContainer.setId(rs2.getInt(1));
							advertisingsContainer.setDate(rs2.getString(2).replaceAll("-", "/"));
							advertisingsContainer.setTitle(rs2.getString(3));
							advertisingsContainer.setReward(rs2.getString(4));
							advertisingsContainer.setLocalization(rs2.getString(5));
							advertisingsContainer.setDescription(rs2.getString(6));
							advertisingsContainer.setVehicleid(rs2.getInt(8));
							advertisingsContainers.add(advertisingsContainer);
						}
						rs2.close();
					}
				tp.closeConnection();
				tokens.remove(token);
			return advertisingsContainers;
		}
		return null;
	}
	
	@Override
	@POST
	@Path("method_16")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.APPLICATION_JSON)
	public PhotographsContainer getPhotos(@FormParam("param")String token, @FormParam("param2")int vehicleid) throws Exception
	{
		if(userValidation(token))
		{
			PhotographsContainer photographsContainer = null;
	
			tblPhotographyVehicle tpv = new tblPhotographyVehicle();
			
				ResultSet rs = tpv.countVehiclePhotos(vehicleid);
					rs.next();
					int size = rs.getInt(1);
					rs.close();
				
		
				if(size > 0)
				{
					photographsContainer = new PhotographsContainer();
						byte[][] photos = new byte[size][];
						int i = 0;
							rs = tpv.selectByVehicle(vehicleid);
							while(rs.next())
							{
									Blob photoBlob = rs.getBlob(2);
									photos[i] = photoBlob.getBytes(1, (int) photoBlob.length());
									i++;
							}
							rs.close();
						photographsContainer.setVehicleid(vehicleid);
						photographsContainer.setPhotos(photos);
				}	
		
			tpv.closeConnection();
			tokens.remove(token);
			return photographsContainer;
		}
		return null;
	}
	
	@Override
	@POST
	@Path("method_17")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.TEXT_PLAIN)
	public int myId(@FormParam("param")String token, @FormParam("param2")String email) throws Exception
	{
		if(userValidation(token))
		{
			
			tblClient tc = new tblClient();
				ResultSet rs = tc.myId(email);
					rs.next();
						int id = rs.getInt(1);
				rs.close();
			tc.closeConnection();
			return id;
		}
		return 0;
	}
	
	@Override
	@POST
	@Path("method_18")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.TEXT_PLAIN)
	public boolean rmAdvertising(@FormParam("param")String token, @FormParam("param2")int id) throws Exception
	{
		if(userValidation(token))
		{
			try
			{
				tblAdvertising ta = new tblAdvertising();
					ta.updateActivity(id, false);
				ta.closeConnection();
				return true;
			}
			catch(Exception e)
			{	
			}
		}
		return false;
	}
		
	@Override
	@POST
	@Path("method_19")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.TEXT_PLAIN)
	public boolean rmVehicle(@FormParam("param")String token, @FormParam("param2")int id) throws Exception
	{
		if(userValidation(token))
		{
			try
			{
				tblVehicle tv = new tblVehicle();
					tv.removeVehicle(id);
				tv.closeConnection();
				return true;
			}
			catch(Exception e)
			{
				
			}
		}
		return false;
	}
	
	
	@Override
	@POST
	@Path("method_20")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.TEXT_PLAIN)
	public boolean rmResult(@FormParam("param")String token, @FormParam("param2")int id) throws Exception
	{
		if(userValidation(token))
		{
			try
			{
				tblPhotographyData tpd = new tblPhotographyData();
					tpd.removePhotographyData(id);
				tpd.closeConnection();
				return true;
			}
			catch(Exception e)
			{	
			}
		}
		return false;
	}
	
	
	@Override
	@POST
	@Path("method_21")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.TEXT_PLAIN)
	public boolean addUserPhoto(@FormParam("param")String json) throws Exception
	{
		ObjectMapper mapper = new ObjectMapper();
		ClientContainer clientContainer = mapper.readValue(json, new TypeReference<ClientContainer>(){});
		if(userValidation(clientContainer.getToken()))
		{
			PhotographyClient photographyClient = new PhotographyClient();
				photographyClient.setId(clientContainer.getId());
				photographyClient.setPhoto(clientContainer.getPhoto());
			try
			{
				tblPhotographyClient tpc = new tblPhotographyClient();
					tpc.insert(photographyClient);
				tpc.closeConnection();
				return true;
			}
			catch(Exception e)
			{
			}
		}
		return false;
	}
	
	@Override
	@POST
	@Path("method_22")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.TEXT_PLAIN)
	public boolean rmUserPhoto(@FormParam("param")String token, @FormParam("param2")int id) throws Exception
	{
		if(userValidation(token))
		{
			try
			{
				tblPhotographyClient tpc = new tblPhotographyClient();
					tpc.deleteBy(id);
				tpc.closeConnection();
				return true;
			}
			catch(Exception e)
			{
			}
		}
		return false;
	}
	
	@Override
	@POST
	@Path("method_23")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.TEXT_PLAIN)
	public boolean upAdvertising(@FormParam("param")String json) throws Exception
	{
		ObjectMapper mapper = new ObjectMapper();
		AdvertisingsContainer advertisingsContainer = mapper.readValue(json, new TypeReference<AdvertisingsContainer>(){});
		if(upAdvertising(advertisingsContainer.getToken()))
		{
			try
			{
				Advertising advertising = new Advertising();
					advertising.setId(advertisingsContainer.getId());
					advertising.setDate(advertisingsContainer.getDate());
					advertising.setTitle(advertisingsContainer.getTitle());
					advertising.setReward(new BigDecimal(advertisingsContainer.getReward()));
					advertising.setLocalization(advertisingsContainer.getLocalization());
					advertising.setDescription(advertisingsContainer.getDescription());
					advertising.setVehicleId(advertisingsContainer.getVehicleid());
				tblAdvertising ta = new tblAdvertising();
					ta.updateBy(advertising);
				
				return true;
			}
			catch(Exception e)
			{
			}
		}
		return false;
	}
	
	
	@Override
	@POST
	@Path("method_24")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.TEXT_PLAIN)
	public boolean upVehicle(@FormParam("param")String json) throws Exception
	{
		ObjectMapper mapper = new ObjectMapper();
		VehiclesContainer vehiclesContainer = mapper.readValue(json, new TypeReference<VehiclesContainer>(){});
		
		if(userValidation(vehiclesContainer.getToken()))
		{
			try
			{
				Vehicle vehicle = new Vehicle();
					vehicle.setId(vehiclesContainer.getId());
					vehicle.setPlate(vehiclesContainer.getPlate());
					vehicle.setBrand(vehiclesContainer.getBrand());
					vehicle.setModel(vehiclesContainer.getModel());
					vehicle.setRegistrationYear(vehiclesContainer.getRegistration_year());
					vehicle.setColor(vehiclesContainer.getColor());
					vehicle.setFuel(vehiclesContainer.getFuel());
					vehicle.setHP(vehiclesContainer.getHp());
					vehicle.setCC(vehiclesContainer.getCc());
					vehicle.setDescription(vehiclesContainer.getDescription());
					vehicle.setClientId(vehiclesContainer.getClientid());
				tblVehicle tv = new tblVehicle();
					tv.updateBy(vehicle);
				
				return true;
			}
			catch(Exception e)
			{
				
			}
		}
		return false;
	}
	
	
	
	@Override
	public boolean userValidation(String token)
	{
		if(tokens.contains(token))
		{
			return true;
		}
		return false;
	}

	@Override
	public void handle(HttpExchange httpExchange) {
		// TODO Auto-generated method stub
		try {
			//Createheader
			httpExchange.sendResponseHeaders(200, 0);
			
			//Token key generator.
			String token = null;
			while(true)
			{
				token = Long.toHexString(Double.doubleToLongBits(Math.random())).toString();
				if(!tokens.contains(token))
				{
					break;
				}
			}
			tokens.add(token);
			
			//Send response with token.
			StringBuilder response = new StringBuilder();
			response.append(token);
			OutputStream os = httpExchange.getResponseBody();
			os.write(response.toString().getBytes());
			os.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
