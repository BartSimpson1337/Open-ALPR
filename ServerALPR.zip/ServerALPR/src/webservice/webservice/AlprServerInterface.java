package webservice;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;

import containers.AdvertisingsContainer;
import containers.CashContainer;
import containers.ClientContainer;
import containers.LoginContainer;
import containers.PhotographsContainer;
import containers.RegisterContainer;
import containers.RequestContainer;
import containers.ResultsContainer;
import containers.VehiclesContainer;
import models.Advertising;
import models.Client;
import models.Payment;
import models.PhotographyData;
import models.Vehicle;
import request.ListOfRequests;

public interface AlprServerInterface {

	boolean login(String json) throws Exception;
	boolean logout(String token, int id) throws Exception;
	boolean register(String json) throws Exception;
	ClientContainer myAccount(String token, int id) throws Exception;
	boolean withdraw(String json) throws Exception;
	boolean deposit(String json) throws Exception;
	boolean request(String json) throws Exception;
	boolean addAdvertising(String json) throws Exception;
	List<AdvertisingsContainer> Advertisings(String token) throws Exception;
	List<AdvertisingsContainer> myAdvertisings(String token, int clientid) throws Exception;
	List<AdvertisingsContainer> AdvertisingsByLocation(String token, String location) throws Exception;
	boolean addVehicle(String json) throws Exception;
	List<VehiclesContainer> myVehicles(String token, int clientid) throws Exception;
	List<ResultsContainer> myResults(String token, int clientid) throws Exception;
	List<AdvertisingsContainer> myRewards(String token, int clientid) throws Exception;
	PhotographsContainer getPhotos(String token, int vehicleid) throws Exception;
	int myId(String token, String email) throws Exception;
	boolean rmAdvertising(String token, int id) throws Exception;
	boolean rmVehicle(String token, int id) throws Exception;
	boolean rmResult(String token, int id) throws Exception;
	boolean addUserPhoto(String json) throws Exception;
	boolean rmUserPhoto(String token, int id) throws Exception;
	boolean upAdvertising(String json) throws Exception;
	boolean upVehicle(String json) throws Exception;
	boolean userValidation(String token);

}
