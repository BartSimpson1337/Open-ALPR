package containers;

import java.math.BigDecimal;

public class ClientContainer {

	private String token;
	private int id;
	private String name;
	private String birth_date;
	private int contact;
	private String email;
	private String password;
	private BigDecimal account_balance;
	private byte[] photo;
	
	public ClientContainer()
	{
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getBirth_date() {
		return birth_date;
	}

	public void setBirth_date(String birth_date) {
		this.birth_date = birth_date;
	}

	public int getContact() {
		return contact;
	}

	public void setContact(int contact) {
		
		int length = (int)(Math.log10(contact)+1);
		if(length == 9)
		{
			this.contact = contact;
		}
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public BigDecimal getAccount_balance() {
		return account_balance;
	}

	public void setAccount_balance(BigDecimal account_balance) {
		this.account_balance = account_balance;
	}

	public byte[] getPhoto() {
		return photo;
	}

	public void setPhoto(byte[] photo) {
		this.photo = photo;
	}

}
