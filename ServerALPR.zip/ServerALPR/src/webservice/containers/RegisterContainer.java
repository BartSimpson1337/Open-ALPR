package containers;

import java.io.Serializable;

public class RegisterContainer implements Serializable{

	private String token;
	private String name;
	private String birth_date;
	private int contact;
	private String email;
	private String password;
	

	public RegisterContainer()
	{
		
	}

	public String getToken() {
		return token;
	}



	public void setToken(String token) {
		this.token = token;
	}

	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public String getBirth_date() {
		return birth_date;
	}



	public void setBirth_date(String birth_date) {
		this.birth_date = birth_date;
	}



	public int getContact() {
		return contact;
	}



	public void setContact(int contact) {
		this.contact = contact;
	}



	public String getEmail() {
		return email;
	}



	public void setEmail(String email) {
		this.email = email;
	}



	public String getPassword() {
		return password;
	}



	public void setPassword(String password) {
		this.password = password;
	}


}
