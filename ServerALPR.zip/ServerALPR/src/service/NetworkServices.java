package service;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.*;


public class NetworkServices {

	//Private String that stores root password.
	private static String password;
	
	public NetworkServices()
	{
	
	}

	public static void getCredencials()
	{
		//Code to scan file where the password was stored. 
		try {
			Scanner scanner = new Scanner( new File("/home/Diogo/Documentos/Projeto EI/rootpw.txt") );
			password = scanner.useDelimiter(";").next();
			scanner.close(); // Put this call in a finally block
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	//####################################TOR service##############################
	public static void startTorService()
	{
        try {
        	String command[] = {"/bin/bash", "-c", "echo"+" "+password+" | sudo -S service tor start"};
        	Process proc = Runtime.getRuntime().exec(command);
        		proc.waitFor();
        }
        catch (Exception e) {
        }
	}
	public static void stopTorService()
	{
        try {
        	String command[] = {"/bin/bash", "-c", "echo"+" "+password+" | sudo -S service tor stop"};
        	Process proc = Runtime.getRuntime().exec(command);
        		proc.waitFor();
        }
        catch (Exception e) {
        }
	}
	public static void restartTorService()
	{
        try {
        	String command[] = {"/bin/bash", "-c", "echo"+" "+password+" | sudo -S service tor restart"};
        	Process proc = Runtime.getRuntime().exec(command);
        		proc.waitFor();
        }
        catch (Exception e) {
        }
	}
	public static boolean statusTorService() 
	{	
		boolean state = false;
		String information = null;
		try {
	    	String command[] = {"/bin/bash", "-c", "echo"+" "+password+" | sudo -S service tor status"};
        	Process proc = Runtime.getRuntime().exec(command);
        		proc.waitFor();

	        BufferedReader stdInput = new BufferedReader(new InputStreamReader(proc.getInputStream()));
	        while ((information = stdInput.readLine()) != null) {
	          //  System.out.println(info);
	        	if(information.contains("active (running)"))
	        	{
	        		//System.out.println(information);
	        		state = true;
	        	}
	        }
	    }
		catch (Exception e) {
	            System.out.println("exception happened - here's what I know: ");
	            e.printStackTrace();
	            System.exit(-1);
	    }
		return state;
	}
	
	//######################################Privoxy service################################
	public static void startPrivoxyService()
	{
        try {
        	String command[] = {"/bin/bash", "-c", "echo"+" "+password+" | sudo -S service privoxy start"};
        	Process proc = Runtime.getRuntime().exec(command);
            	proc.waitFor();
        }
        catch (Exception e) {
        }
	}
	public static void stopPrivoxyService()
	{
        try {
        	String command[] = {"/bin/bash", "-c", "echo"+" "+password+" | sudo -S service privoxy stop"};
        	Process proc = Runtime.getRuntime().exec(command);
                proc.waitFor();
        }
        catch (Exception e) {
        }
	}
	public static void restartPrivoxyService()
	{
        try {
        	String command[] = {"/bin/bash", "-c", "echo"+" "+password+" | sudo -S service privoxy restart"};
        	Process proc = Runtime.getRuntime().exec(command);
            	proc.waitFor();
        }
        catch (Exception e) {
        }
	}
	public static boolean statusPrivoxyService()
	{
		boolean state = false;
		String information = null;
		try {
	    	String command[] = {"/bin/bash", "-c", "echo"+" "+password+" | sudo -S service privoxy status"};
        	Process proc = Runtime.getRuntime().exec(command);
        		proc.waitFor();
        		
        	BufferedReader stdInput = new BufferedReader(new InputStreamReader(proc.getInputStream()));
	        while ((information = stdInput.readLine()) != null) {
	          //  System.out.println(info);
	        	if(information.contains("active (running)"))
	        	{
	        		//System.out.println(information);
	        		state = true;
	        	}
	        }
	    }
		catch (Exception e) {
	            System.out.println("exception happened - here's what I know: ");
	            e.printStackTrace();
	            System.exit(-1);
	    }
		return state;
	}
	
	public static void setProxyServer()
	{
		//Code that connects to host http and https proxy.
		System.setProperty("http.proxyHost", "127.0.0.1"); 
	    System.setProperty("http.proxyPort", "8118");	
	}
}
