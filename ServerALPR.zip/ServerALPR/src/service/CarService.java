package service;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.CookieHandler;
import java.net.CookieManager;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.net.ssl.HttpsURLConnection;

//import javax.net.ssl.HttpsURLConnection;
import java.net.HttpURLConnection;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.drew.lang.SequentialByteArrayReader;



public class CarService {
	
	//Connection attributes
	private String regExpr;
	private String urlPage1;
	private String urlPage2;
	private List<String> cookies;
	private HttpsURLConnection conn;
	private final String USER_AGENT = "Mozilla/5.0";
	
	//Car attributes
	private static String plate;
	private static String brand;
	private static String model;
	private static String year;
	private static String fuel;
	private static String color;
	private static String type;
	private static String cc;
	private static String hp;

	public CarService() throws Exception
	{
		this.urlPage1 = "http://auto.sapo.pt/VendaJa/";
		this.urlPage2 = "http://auto.sapo.pt/VendaJa/Vender";
	}
	public void Connection() throws Exception
	{
	  CarService http = new CarService();
	  
	  CookieHandler.setDefault(new CookieManager());
	  
	  // 1. Send a "GET" request, so that you can extract the form's data.
	  String page = http.GetPageContent(this.urlPage1);
	  String postParams = http.getFormParams(page, this.plate);
	  
	  
	  // 2. Construct above post's content and then send a POST request for
	  // authentication
	  http.sendPost(this.urlPage1, postParams);

	  // 3. success then go to gmail.
	  String result = http.GetPageContent(this.urlPage2);
	  //System.out.println(result);
	}


	private String getFormParams(String html, String plate) throws Exception {
	// TODO Auto-generated method stub
	  	System.out.println("Extracting form's data...");

		Document doc = Jsoup.parse(html);
		
		// Google form id
		Element loginform = doc.getElementById("IndexFormBig");
		Elements inputElements = loginform.getElementsByTag("input");
		List<String> paramList = new ArrayList<String>();
		for (Element inputElement : inputElements) {
			String key = inputElement.attr("name");
			String value = inputElement.attr("value");

			if (key.equals("RegistrationPlate"))
				value = plate;
			
			paramList.add(key + "=" + URLEncoder.encode(value, "UTF-8"));
		}

		// build parameters list
		StringBuilder result = new StringBuilder();
		for (String param : paramList) {
			if (result.length() == 0) {
				result.append(param);
			} else {
				result.append("&" + param);
			}
		}
		
		return result.toString();
	}


	private void sendPost(String url, String postParams) throws Exception {
	// TODO Auto-generated method stub

	  	URL obj = new URL(url);
	  	HttpURLConnection conn = (HttpURLConnection) obj.openConnection();
			// Acts like a browser
			conn.setUseCaches(false);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Host", "auto.sapo.pt");
			conn.setRequestProperty("User-Agent", USER_AGENT);
			conn.setRequestProperty("Accept",
				"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
			conn.setRequestProperty("Accept-Language", "en-US,en;q=0.5");
			for (String cookie : this.cookies) {
				conn.addRequestProperty("Cookie", cookie.split(";", 1)[0]);
			}
			conn.setRequestProperty("Connection", "keep-alive");
			conn.setRequestProperty("Referer", "http://auto.sapo.pt/VendaJa/");
			conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
			conn.setRequestProperty("Content-Length", Integer.toString(postParams.length()));
			
			conn.setDoOutput(true);
			conn.setDoInput(true);
		
		// Send post request
		DataOutputStream wr = new DataOutputStream(conn.getOutputStream());
			wr.writeBytes(postParams);
			wr.flush();
			wr.close();
		
		int responseCode = conn.getResponseCode();
			System.out.println("\nSending 'POST' request to URL : " + url);
			System.out.println("Post parameters : " + postParams);
			System.out.println("Response Code : " + responseCode);
			
	  //System.out.println("##########################################CODE#############################");
			BufferedReader in =
		             new BufferedReader(new InputStreamReader(conn.getInputStream()));
			String inputLine;
			StringBuffer response = new StringBuffer();
			int line = 0;
			while ((inputLine = in.readLine()) != null) {
				line++;
				response.append(inputLine);
				
				if(line == 250 && inputLine.contains("<h4>Não encontrámos informação sobre a sua matrícula.<br/> Por favor introduza os dados da viatura manualmente.</h4>"))
				{
					System.out.println("No data found!");
					
					break;
				}
				else
				{
					switch (line) {
						case 256:
						      setCC(regularExpression(inputLine, "<input data-val=\"true\" data-val-number=\"The field CC must be a number.\" id=\"CC\" name=\"CC\" type=\"hidden\" value=\"(.+?)\""));
						      setHP(regularExpression(inputLine,"<input data-val=\"true\" data-val-number=\"The field HP must be a number.\" id=\"HP\" name=\"HP\" type=\"hidden\" value=\"(.+?)\" />"));
						break;
						case 261:
							  setBrand(regularExpression(inputLine,"<p class=\"bg_gray no_space_bottom\">(.+?)</p>"));
						break;
						case 268:
							  setModel(regularExpression(inputLine,"<p class=\"bg_gray no_space_bottom\">(.+?)</p>"));
						break;
						case 277:
							  setYear(regularExpression(inputLine,"<p class=\"bg_gray no_space_bottom\">(.+?)</p>"));
						break;
						case 284:
							  setFuel(regularExpression(inputLine,"<p class=\"bg_gray no_space_bottom\">(.+?)</p>"));
						break;
						case 292:
							  setColor(regularExpression(inputLine,"<p class=\"bg_gray no_space_bottom\">(.+?)</p>"));
						break;
						case 301:
							  setType(regularExpression(inputLine,"<p class=\"bg_gray\">(.+?)</p>"));
						break;
					}	
				}
			}
			in.close();
			// System.out.println(response.toString());
	//	System.out.println("##########################################End CODE#############################");
	}


	private String GetPageContent(String url) throws Exception {
	// TODO Auto-generated method stub
	  	URL obj = new URL(url);
	  	HttpURLConnection conn = (HttpURLConnection) obj.openConnection();
	  	
			// default is GET
			conn.setRequestMethod("GET");
			conn.setUseCaches(false);

			// act like a browser
			conn.setRequestProperty("User-Agent", USER_AGENT);
			conn.setRequestProperty("Accept",
				"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
			conn.setRequestProperty("Accept-Language", "en-US,en;q=0.5");
			if (cookies != null) {
				for (String cookie : this.cookies) {
					conn.addRequestProperty("Cookie", cookie.split(";", 1)[0]);
				}
			}
		
		int responseCode = conn.getResponseCode();
			System.out.println("\nSending 'GET' request to URL : " + url);
			System.out.println("Response Code : " + responseCode);
		
	//	System.out.println("##########################################CODE#############################");
			BufferedReader in =
		            new BufferedReader(new InputStreamReader(conn.getInputStream()));
			String inputLine;
			StringBuffer response = new StringBuffer();
			
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();
	//	System.out.println("##########################################End CODE#############################");
		
		// Get the response cookies
		setCookies(conn.getHeaderFields().get("Set-Cookie"));
		
		return response.toString(); 
	}
	public List<String> getCookies() {
		return cookies;
	}
	public void setCookies(List<String> cookies) {
		this.cookies = cookies;
	}	
	
	private String regularExpression(String inputLine, String regExpr)
	{
			final Pattern pattern = Pattern.compile(regExpr);
			final Matcher matcher = pattern.matcher(inputLine);
			matcher.find();
			//System.out.println(matcher.group(1));	
			return matcher.group(1);
	}
	
	//set
	public void setPlate(String plate)
	{
		this.plate = plate;
	}
	public void setBrand(String brand)
	{
		this.brand = brand;
	}
	public void setModel(String model)
	{
		this.model = model;
	}
	public void setYear(String year)
	{
		this.year = year;
	}
	public void setFuel(String fuel)
	{
		this.fuel = fuel;
	}
	public void setColor(String color)
	{
		this.color = color;
	}
	public void setType(String type)
	{
		this.type = type;
	}
	public void setCC(String cc)
	{
		this.cc = cc;
	}
	public void setHP(String hp)
	{
		this.hp = hp;
	}
	
	public String getPlate()
	{
		return this.plate;
	}
	public String getBrand()
	{
		return this.brand;
	}
	public String getModel()
	{
		return this.model;
	}
	public String getYear()
	{
		return this.year;
	}
	public String getFuel()
	{
		return this.fuel;
	}
	public String getColor()
	{
		return this.color;
	}
	public String getType()
	{
		return this.type;
	}
	public String getCC()
	{
		return this.cc;
	}
	public String getHP()
	{
		return this.hp;
	}
	

	
	
}

