package service;

import java.io.IOException;

import org.apache.commons.io.IOExceptionWithCause;

import eu.bitm.NominatimReverseGeocoding.NominatimReverseGeocodingJAPI;
public class GeolocationService {

	private Double latitude;
	private Double longitude;
	
	private String geolocation = null;
	private String countrycode = null;
	private String country = null;
	private String postcode = null;
	private String state = null;
	private String county = null;
	private String city = null;
	private String suburb = null;
	private String road = null;
	
	
	
	public GeolocationService(Double latitude, Double longitude)
	{
		this.latitude = latitude;
		this.longitude = longitude;
			try {
				getLocation();
			} catch (Exception e) {
				// TODO Auto-generated catch block
			
			}
		
	}
	private void getLocation() throws Exception
	{
			NominatimReverseGeocodingJAPI nominatim1 = new NominatimReverseGeocodingJAPI();
				setGeolocation(nominatim1.getAdress(this.latitude, this.longitude).getDisplayName());//returns Address object for the given position
				setCountryCode(nominatim1.getAdress(this.latitude, this.longitude).getCountryCode());
				setCountry(nominatim1.getAdress(this.latitude, this.longitude).getCountry());
				setPostCode(nominatim1.getAdress(this.latitude, this.longitude).getPostcode());
				setState(nominatim1.getAdress(this.latitude, this.longitude).getState());
				setCounty(nominatim1.getAdress(this.latitude, this.longitude).getCounty());
				setCity(nominatim1.getAdress(this.latitude, this.longitude).getCity());
				setSuburb(nominatim1.getAdress(this.latitude, this.longitude).getSuburb());
				setSuburb(nominatim1.getAdress(this.latitude, this.longitude).getRoad());
	}
	//set
	private void setGeolocation(String geolocation)
	{
		this.geolocation = geolocation;
	}
	private void setCountryCode(String countrycode)
	{
		this.countrycode = countrycode;
	}
	private void setCountry(String country)
	{
		this.country = country;
	}
	private void setPostCode(String postcode)
	{
		this.postcode = postcode;
	}
	private void setState(String state)
	{
		this.state = state;
	}
	private void setCounty(String county)
	{
		this.county = county;
	}
	private void setCity(String city)
	{
		this.city = city;
	}

	private void setSuburb(String suburb)
	{
		this.suburb = suburb;
	}
	private void setRoad(String road)
	{
		this.road = road;
	}
	
	//get
	public String getGeolocation()
	{
		return this.geolocation;
	}
	public String getCountryCode()
	{
		return this.countrycode;
	}
	public String getCountry()
	{
		return this.country;
	}
	public String getPostCode()
	{
		return this.postcode;
	}
	public String getState()
	{
		return this.state;
	}
	public String getCounty()
	{
		return this.county;
	}
	public String getCity()
	{
		return this.city;
	}
	public String getSuburb()
	{
		return this.suburb;
	}
	public String getRoad()
	{
		return this.road;
	}
}
