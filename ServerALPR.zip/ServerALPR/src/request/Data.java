package request;

import java.util.List;

import image.CameraParameters;

public class Data {
		
	private byte[][] photos;
	private List<CameraParameters> parameters;
	
	public Data()
	{
	}

	public byte[][] getPhotos() {
		return photos;
	}

	public void setPhotos(byte[][] photos) {
		this.photos = photos;
	}

	public List<CameraParameters> getParameters() {
		return parameters;
	}

	public void setParameters(List<CameraParameters> parameters) {
		this.parameters = parameters;
	}
	
}
