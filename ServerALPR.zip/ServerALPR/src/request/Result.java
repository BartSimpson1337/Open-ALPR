package request;

import java.sql.Date;
import java.sql.Time;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.LinkedList;

import com.openalpr.jni.AlprResults;

import image.MetaData;

public class Result {

	private String imagePath;
	private String plate;
	private float confidencePlate;
	private float processingTime;
	private String brand;
	private String model;
	private String year;
	private String fuel;
	private String color;
	private String type;
	private String hp;
	private String cc;
	private String geolocation;
	private Double latitude;
	private Double longitude;
	private String date;
	private String time;
	
	public Result()
	{
	}
	public void setImagePath(String imagepath)
	{
		this.imagePath = imagepath;
	}
	public void setPlate(String plate)
	{
		this.plate = plate;
		
	}
	public void setConfidencePlate(float confidencePlate)
	{
		this.confidencePlate = confidencePlate;
	}
	public void setProcessingTime(float processingTime)
	{
		this.processingTime = processingTime;
	}
	public void setDate(String date) throws ParseException
	{
		this.date = date;
	}
	public void setTime(String time) throws ParseException
	{
		this.time = time;
	}
	public void setBrand(String brand)
	{
		this.brand = brand;
	}
	public void setModel(String model)
	{
		this.model = model;
	}
	public void setYear(String year)
	{
		this.year = year;
	}
	public void setFuel(String fuel)
	{
		this.fuel = fuel;
	}
	public void setColor(String color)
	{
		this.color = color;
	}
	public void setType(String type)
	{
		this.type = type;
	}
	public void setHP(String hp)
	{
		this.hp = hp;
	}
	public void setCC(String cc)
	{
		this.cc = cc;
	}
	public void setGeolocation(String geolocation)
	{
		this.geolocation = geolocation;
	}
	public void setLatitude(Double latitude)
	{
		this.latitude = latitude;
	}
	public void setLongitude(Double longitude)
	{
		this.longitude = longitude;
	}
	
	public String getImagePath()
	{
		return this.imagePath;
	}
	public String getPlate()
	{
		return this.plate;
	}
	public float getConfidencePlate()
	{
		return this.confidencePlate;
	}
	public float getProcessingTime()
	{
		return this.processingTime;
	}
	public String getDate()
	{
		return this.date;
	}
	public String getTime()
	{
		return this.time;
	}
	public String getBrand()
	{
		return this.brand;
	}
	public String getModel()
	{
		return this.model;
	}
	public String getYear()
	{
		return this.year;
	}
	public String getFuel()
	{
		return this.fuel;
	}
	public String getColor()
	{
		return this.color;
	}
	public String getType()
	{
		return this.type;
	}
	public String getHP()
	{
		return this.hp;
	}
	public String getCC()
	{
		return this.cc;
	}
	public String getGeolocation()
	{
		return this.geolocation;
	}
	public Double getLatitude()
	{
		return this.latitude;
	}
	public Double getLongitude()
	{
		return this.longitude;
	}
	
	public void showCharacteristics() //teste
	{
		System.out.println("Matricula:"+plate);
		System.out.println("\nMarca:"+brand);
		System.out.println("\nModelo:"+model);
		System.out.println("\nAno:"+year);
		System.out.println("\nCombustivel:"+fuel);
		System.out.println("\nCor:"+color);
		System.out.println("\nTipo Carroçaria:"+type);
		System.out.println("\nCavalos:"+hp);
		System.out.println("\nCilindrada:"+cc);
	}
}
