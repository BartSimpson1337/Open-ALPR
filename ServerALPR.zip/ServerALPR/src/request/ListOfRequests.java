package request;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.text.ParseException;
import java.util.Iterator;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import javax.swing.SwingUtilities;

import com.openalpr.jni.AlprPlate;
import com.openalpr.jni.AlprPlateResult;
import com.openalpr.jni.AlprResults;

import image.Image;
import image.ListOfImages;
import image.MetaData;
import image.RegistrationPlateCover;
import models.Photography;
import models.PhotographyData;
import models.PhotographyVehicle;
import models.Send;
import models.Vehicle;
import querys.DataBase;
import querys.Search;
import querys.tblPhotography;
import querys.tblPhotographyData;
import querys.tblPhotographyVehicle;
import querys.tblSend;
import querys.tblVehicle;

public class ListOfRequests {

	
	private Request rq;
	private LinkedBlockingQueue<Request> requestList;
	private LinkedBlockingQueue<Request> executedRequestList;
	
	//Instância as filas de pedidos pendentes e de pedidos executados
	public ListOfRequests()
	{
		this.requestList = new LinkedBlockingQueue<>(64);
		this.executedRequestList = new LinkedBlockingQueue<>(64);
	}
	
	//Cria threads consuante os cores do CPU para serem utilizados nas filas instânciadas.
	public void multiThreading()
	{	
		Thread[] threads = new Thread[Runtime.getRuntime().availableProcessors()];
		for (int i = 0; i < threads.length; i++) {
			threads[i] = new Thread(new ListOfImages(this.requestList, this.executedRequestList));
			threads[i].start(); 
		}
	}
	
	//Insere um novo pedido na fila.
	public void offer(Request r)
	{
		this.requestList.offer(r);
	}
	
	//Retira um pedido da fila de pedidos executados.
	public void take()
	{
		while(true)
		{		
			try {

				this.rq = this.executedRequestList.take();
				System.out.println("\n Request ID: "+rq.getUserId());
				System.out.println("\n\t Send Date: "+rq.getSendDate()+" Time: "+rq.getSendTime());
				
				//Insere na tabela envios da base de dados e guarda o id desse registo.
				int key = 0;
				if(rq.getRequestType() == 1)
				{
				    key = insertSend(rq.getSendDate(), rq.getSendTime(), rq.getExecutionDate(), rq.getExecutionTime(), rq.getUserId());
				}
				for(Result rs:this.rq.getResultList()) //Percorre todas os resultados do pedido executado.
				{
					System.out.println("\n| Localização: "+rs.getGeolocation()+"\n| Matricula: "+rs.getPlate()+"\n| Confiança: "+rs.getConfidencePlate()+" % \n| Tempo Processamento: "+rs.getProcessingTime()+" ms \n| Marca: "+rs.getBrand()+"\n| Modelo: "+rs.getModel()+"\n| Ano: "+rs.getYear()+" \n| Cor : "+rs.getColor()+"\n| Combustível: "+rs.getFuel()+" \n| cv :"+rs.getHP()+"\n| cc: "+rs.getCC());
				
					//Insere os resultados na tabela resultados e as respetivas fotos.
					if(rq.getRequestType() == 1)
					{
						int year, hp, cc;
						if(rs.getYear() != null || rs.getHP() != null || rs.getCC() != null)
						{
							year = Integer.valueOf(rs.getYear());
							hp = Integer.valueOf(rs.getHP());
						    cc = Integer.valueOf(rs.getCC());
						}
						else
						{
							year = 0;
							hp = 0;
							cc = 0;
						}
							
							
							
						int key2 = insertPhotographyData(rs.getDate(), rs.getTime(), rs.getGeolocation(), rs.getLatitude(), rs.getLongitude(), rs.getPlate(), rs.getConfidencePlate(), rs.getBrand(), rs.getModel(), year, rs.getColor(), rs.getFuel(), hp, cc, key);
								   insertPhotography(key2 ,rs.getImagePath());
								   Search se = new Search(key2, rs.getPlate());
					}
					else
					{
						//Caso o pedido seja do tipo 0 insere o novo veiculo.
						insertVehicle(rs.getImagePath(), rs.getPlate(), rs.getBrand(), rs.getModel(), Integer.parseInt(rs.getYear()), rs.getColor(), rs.getFuel(), Integer.parseInt(rs.getHP()), Integer.parseInt(rs.getCC()), rq.getUserId());	
					
					}
					//Apaga os ficheiros temporários criados.
					Files.delete(Paths.get(rs.getImagePath()));
				}
				System.out.println("\t Execution Date: "+rq.getExecutionDate()+" Time: "+rq.getExecutionTime());
			
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}

	//Insere um envio na tabela envios da base de dados, retornando o id do registo inserido.
	private int insertSend(String send_date, String send_time, String executed_date, String executed_time, int clientid) throws SQLException
	{
		int key;
		Send s = new Send();
			s.setSendDate(send_date);
			s.setSendTime(send_time);
			s.setExecutedDate(executed_date);
			s.setExecutedTime(executed_time);
			s.setClientId(clientid);
		tblSend ts = new tblSend();
		key =(int)ts.insert(s);
		ts.closeConnection();
		return key;
	}
	
	//Insere um resultado na tabela PhotographyData retornando o id do registo inserido.
	private int insertPhotographyData(String date, String time, String geolocation, double latitude, double longitude, String plate, float confidence, String brand, String model, int registration_year, String color, String fuel, int hp, int cc, int sendid) throws SQLException
	{
		int key;
		
			PhotographyData pd = new PhotographyData();
				pd.setDate(date);
				pd.setTime(time);
				pd.setGeolocation(geolocation);
				pd.setLatitude(latitude);
				pd.setLongitude(longitude);
				pd.setPlate(plate);
				pd.setConfidence(confidence);
				pd.setBrand(brand);
				pd.setModel(model);
				pd.setRegistrationYear(registration_year);
				pd.setColor(color);
				pd.setFuel(fuel);
				pd.setHP(hp);
				pd.setCC(cc);
				pd.setSendId(sendid);
			tblPhotographyData tpd = new tblPhotographyData();
				key = (int)tpd.insert(pd);
				tpd.closeConnection();
				return key;
	}
	
	//Insere uma fotografia, associada ao resultado.
	private void insertPhotography(int photographydataid, String imagepath) throws IOException, SQLException //inserts blob pictures into database.
	{
			Photography p = new Photography();
				p.setId(photographydataid);
				p.setPhoto(imagepath);
			tblPhotography tp = new tblPhotography();
				tp.insert(p);
				tp.closeConnection();
	}
	
	//Insere um novo veículo, tendo em conta se ele já existe ou não.
	private void insertVehicle(String imagepath, String plate, String brand, String model, int registration_year, String color, String fuel, int hp, int cc, int clientid) throws SQLException, IOException
	{
			Vehicle v = new Vehicle();
				v.setPlate(plate);
				v.setBrand(brand);
				v.setModel(model);
				v.setRegistrationYear(registration_year);
				v.setColor(color);
				v.setFuel(fuel);
				v.setHP(hp);
				v.setCC(cc);
				v.setClientId(clientid);
			tblVehicle tv = new tblVehicle();
				ResultSet rs = tv.checkUnique(plate);
					rs.next();
					if(rs.getInt(1) == 0)
					{
						//Caso não exista insere o novo veículo e a foto correspondente.
						insertPhotographyVehicle(imagepath, (int) tv.insert(v));
					}
					else
					{
						//Caso já exista verifica se ele ta desativado, para ativar.
						ResultSet rs2 = tv.selectClient_v2(clientid);
						while(rs2.next())
						{
							if(rs2.getString(2).equalsIgnoreCase(plate))
							{
								insertPhotographyVehicle(imagepath, rs2.getInt(1));
								if(rs2.getBoolean(12) == false)
								{
									tv.activateVehicle(rs2.getInt(1));
								}
							}
						}
						rs2.close();
					}
				rs.close();
			tv.closeConnection();
	}
	
	//Insere as fotos referentes a veiculos na tabela PhotographyVehicle.
	private void insertPhotographyVehicle(String imagepath, int vehicleid) throws SQLException, IOException 
	{
			PhotographyVehicle pv = new PhotographyVehicle();
				pv.setPhoto(imagepath);
				pv.setVehicleId(vehicleid);
			tblPhotographyVehicle tpv = new tblPhotographyVehicle();
				tpv.insert(pv);
				tpv.closeConnection();
	}

}
