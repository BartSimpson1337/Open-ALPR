package request;
import java.io.File;
import java.sql.SQLException;
import java.sql.Time;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import image.MetaData;
import models.Send;
import querys.tblSend;


public class Request {

	private int user_id; 
	private int requestType;
	private String sendDate;
	private String sendTime;
	private String executionDate;
	private String executionTime;
	private List<Result> resultList; 
	private Data data;
	
	public Request(int user_id, int requestType)
	{
		this.user_id = user_id;
		this.requestType = requestType;
		this.sendDate = getCurrentDate();
		this.sendTime = getCurrentTime();
		this.resultList = new ArrayList<Result>();;
		
	}
	private String getCurrentDate()
	{
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
		Date date = new Date();
		return dateFormat.format(date);
	}
	private String getCurrentTime()
	{
		DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
		Date date = new Date();
		return dateFormat.format(date);
	}
	public int getUserId()
	{
		return this.user_id;
	}
	public int getRequestType()
	{
		return this.requestType;
	}
	public String getSendDate()
	{
		return this.sendDate;
	}
	public String getSendTime()
	{
		return this.sendTime;
	}
	
	public String getExecutionDate()
	{
		return this.executionDate;
	}
	public String getExecutionTime()
	{
		return this.executionTime;
	}
	public List<Result> getResultList()
	{
		return this.resultList;
	}

	public void setExecutionDate()
	{
		this.executionDate = getCurrentDate();
	}
	public void setExecutionTime()
	{
		this.executionTime = getCurrentTime();
	}
	public void setResult(Result r)
	{
		this.resultList.add(r);
	}
	public Data getData() {
		return data;
	}
	public void setData(Data data) {
		this.data = data;
	}
}
