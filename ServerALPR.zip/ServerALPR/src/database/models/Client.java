package models;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;


public class Client {

	private int Id;
	private String name;
	private Date birth_date;
	private int contact;
	private String email;
	private String password;
	private BigDecimal account_balance;
	
	public Client()
	{
	}
	
	public int getId()
	{
		return this.Id;
	}
	public String getName()
	{
		return this.name;
	}

	public Date getBirthDate()
	{
		return this.birth_date;
	}
	public int getContact()
	{
		return this.contact;
	}
	public String getEmail()
	{
		return this.email;
	}
	public String getPassword()
	{
		return this.password;
	}
	public BigDecimal getAccountBalance()
	{
		return this.account_balance;
	}
	public void setId(int Id)
	{
		this.Id = Id;
	}
	public void setName(String name)
	{
		this.name = name;
	}
	public void setBirthDate(String birth_date) throws ParseException
	{
		DateFormat formated = new SimpleDateFormat("yyyy/MM/dd");
		java.sql.Date sqlDate = new java.sql.Date(formated.parse(birth_date).getTime());
		
		this.birth_date = sqlDate;
	}
	public void setContact(int contact)
	{
		int length = (int)(Math.log10(contact)+1);
		if(length == 9)
		{
			this.contact = contact;
		}
	}
	public void setEmail(String email)
	{
		this.email = email;
	}
	public void setPassword(String password)
	{
		this.password = password;
	}
	public void setAccountBalance(BigDecimal account_balance)
	{
		this.account_balance = account_balance;
		
	}

}
