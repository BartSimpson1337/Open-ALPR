package models;

public class Vehicle {

	private int Id;
	private String plate;
	private String brand;
	private String model;
	private int registration_year;
	private String color;
	private String fuel;
	private int hp;
	private int cc;
	private String description;
	private int Client_Id;
	
	public Vehicle()
	{
	}
	
	public int getId()
	{
		return this.Id;
	}
	public String getPlate()
	{
		return this.plate;
	}
	public String getBrand()
	{
		return this.brand;
	}
	public String getModel()
	{
		return this.model;
	}
	public int getRegistrationYear()
	{
		return this.registration_year;
	}
	public String getColor()
	{
		return this.color;
	}
	public String getFuel()
	{
		return this.fuel;
	}
	public int getHP()
	{
		return this.hp;
	}
	public int getCC()
	{
		return this.cc;
	}
	public String getDescription()
	{
		return this.description;
	}
	public int getClientId()
	{
		return this.Client_Id;
	}
	
	public void setId(int id)
	{
		this.Id = id;
	}
	public void setPlate(String plate)
	{
		this.plate = plate;
	}
	public void setBrand(String brand)
	{
		this.brand = brand;
	}
	public void setModel(String model)
	{
		this.model = model;
	}
	public void setRegistrationYear(int registration_year)
	{
		this.registration_year = registration_year;
	}
	public void setColor(String color)
	{
		this.color = color;
	}
	public void setFuel(String fuel)
	{
		this.fuel = fuel;
	}
	public void setHP(int hp)
	{
		this.hp = hp;
	}
	public void setCC(int cc)
	{
		this.cc = cc;
	}
	public void setDescription(String description)
	{
		this.description = description;
	}
	public void setClientId(int clientid)
	{
		this.Client_Id = clientid;
	}
}
