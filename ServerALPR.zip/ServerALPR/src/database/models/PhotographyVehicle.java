package models;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.SQLException;

import javax.imageio.ImageIO;

public class PhotographyVehicle {

	private int Id;
	private byte[] photo;
	private int Vehicle_Id;
	
		public PhotographyVehicle()
		{
		}
		
		public int getId()
		{
			return this.Id;
		}
		public byte[] getPhoto()
		{
			return this.photo;				
		}
		public int getVehicleId()
		{
			return this.Vehicle_Id;
		}
		
		public void setId(int id)
		{
			this.Id = id;
		}
		public void setPhoto(String path) throws IOException, SQLException
		{
			//Read buffered image.
			BufferedImage originalImage = ImageIO.read(new File(
					path));
			//Convert buffered image to byte array.
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			ImageIO.write(originalImage, "jpg", baos);
			baos.flush();
				this.photo = baos.toByteArray(); //Store byte array image.
			baos.close();
			
			
			//Convert blob to array byte to buffered image and to file. Backup code.
			/*Blob imageBlob = resultSet.getBlob(2);
	      	byte[] imageBytes = imageBlob.getBytes(1, (int) imageBlob.length());
	      	
	      	//Convert byte array to image.
	      	InputStream in = new ByteArrayInputStream(imageBytes);
			BufferedImage bImageFromConvert = ImageIO.read(in);

			//Save buffered image in file system.
			ImageIO.write(bImageFromConvert, "jpg", new File(
					"/home/Diogo/Documentos/Projeto EI/openalpr/src/build/Photos/test1/newimg"+String.valueOf(index++)+".jpg"));*/
			
		}

		public void setVehicleId(int vehicleid)
		{
			this.Vehicle_Id = vehicleid;
		}
		
}
