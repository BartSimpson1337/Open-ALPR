package models;

public class PhotographyClient {
	
	private int Id;
	private byte[] photo;
	
	public PhotographyClient(){
		
	}

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public byte[] getPhoto() {
		return photo;
	}

	public void setPhoto(byte[] photo) {
		this.photo = photo;
	}
	
	
}
