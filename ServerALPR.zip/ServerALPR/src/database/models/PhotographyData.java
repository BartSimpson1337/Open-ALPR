package models;

import java.sql.Date;
import java.sql.Time;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class PhotographyData {

	private int Id;
	private Date date;
	private Time time;
	private String geolocation;
	private double latitude;
	private double longitude;
	private String plate;
	private float confidence;
	private String brand;
	private String model;
	private int registration_year;
	private String color;
	private String fuel;
	private int hp;
	private int cc;
	private int Send_Id;
	
	public PhotographyData()
	{
	}
	
	public int getId()
	{
		return this.Id;
	}
	public Date getDate()
	{
		return this.date;
	}
	public Time getTime()
	{
		return this.time;
	}
	public String getGeolocation()
	{
		return this.geolocation;
	}
	public double getLatitude()
	{
		return this.latitude;
	}
	public double getLongitude()
	{
		return this.longitude;
	}
	public String getPlate()
	{
		return this.plate;
	}
	public float getConfidence()
	{
		return this.confidence;
	}
	public String getBrand()
	{
		return this.brand;
	}
	public String getModel()
	{
		return this.model;
	}
	public int getRegistrationYear()
	{
		return this.registration_year;
	}
	public String getColor()
	{
		return this.color;
	}
	public String getFuel()
	{
		return this.fuel;
	}
	public int getHP()
	{
		return this.hp;
	}
	public int getCC()
	{
		return this.cc;
	}
	public int getSendId()
	{
		return this.Send_Id; 
	}
	
	public void setId(int id)
	{
		this.Id = id;
	}
	public void setDate(String date)
	{
		try
		{
			DateFormat formated = new SimpleDateFormat("yyyy/MM/dd");
			java.sql.Date sqlDate = new java.sql.Date(formated.parse(date).getTime());
			this.date = sqlDate;
		}
		catch(Exception e){}
	}
	public void setTime(String time)
	{
		try 
		{
			DateFormat formated = new SimpleDateFormat("hh:mm:ss");
			java.sql.Time sqlTime = new java.sql.Time(formated.parse(time).getTime());
			this.time = sqlTime;
		}
		catch(Exception e){}
	}
	public void setGeolocation(String geolocation)
	{
		this.geolocation = geolocation;
	}
	public void setLatitude(double latitude)
	{
		this.latitude = latitude;
	}
	public void setLongitude(double longitude)
	{
		this.longitude = longitude;
	}
	public void setPlate(String plate)
	{
		this.plate = plate;
	}
	public void setConfidence(float confidence)
	{
		this.confidence = confidence;
	}
	public void setBrand(String brand)
	{
		this.brand = brand;
	}
	public void setModel(String model)
	{
		this.model = model;
	}
	public void setRegistrationYear(int registration_year)
	{
		this.registration_year = registration_year;
	}
	public void setColor(String color)
	{
		this.color = color;
	}
	public void setFuel(String fuel)
	{
		this.fuel = fuel;
	}
	public void setHP(int hp)
	{
		this.hp = hp;
	}
	public void setCC(int cc)
	{
		this.cc = cc;
	}
	public void setSendId(int sendid)
	{
		this.Send_Id = sendid;
	}
}
