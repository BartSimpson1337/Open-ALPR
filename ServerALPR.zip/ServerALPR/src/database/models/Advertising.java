package models;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class Advertising {

	private int Id;
	private Date date;
	private String title;
	private BigDecimal reward;
	private String localization;
	private String description;
	private int Vehicle_Id;
	
	public Advertising()
	{
	}
	
	public int getId()
	{
		return this.Id;
	}
	public Date getDate()
	{
		return this.date;
	}
	public String getTitle()
	{
		return this.title;
	}
	public BigDecimal getReward()
	{
		return this.reward;
	}
	public String getLocalization()
	{
		return this.localization;
	}
	public String getDescription()
	{
		return this.description;
	}
	public int getVehicleId()
	{
		return this.Vehicle_Id;
	}
	
	
	public void setId(int id)
	{
		this.Id = id;
	}
	public void setDate(String date) throws ParseException
	{
		DateFormat formated = new SimpleDateFormat("yyyy/MM/dd");
		java.sql.Date sqlDate = new java.sql.Date(formated.parse(date).getTime());
		
		this.date = sqlDate;
	}
	public void setTitle(String title)
	{
		this.title = title;
	}
	public void setReward(BigDecimal reward)
	{
		this.reward = reward;
	}
	public void setLocalization(String localization)
	{
		this.localization = localization;
	}
	public void setDescription(String description)
	{
		this.description = description;
	}

	public void setVehicleId(int vehicleid)
	{
		this.Vehicle_Id = vehicleid;
	}

			
	
	
}
