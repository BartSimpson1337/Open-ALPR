package models;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.SQLException;

import javax.imageio.ImageIO;

public class Photography {

	private int Id;
	private byte[] photo;
	
	public Photography()
	{
	}
	
	public int getId()
	{
		return this.Id;
	}
	public byte[] getPhoto()
	{
		return this.photo;
	}
	
	public void setId(int id)
	{
		this.Id = id;
	}
	public void setPhoto(String path) throws IOException, SQLException
	{
		File in = new File(path);
        InputStream input = new FileInputStream(in);

         byte[] buff = new byte[(int) in.length()];
         int bytesRead = 0;

         ByteArrayOutputStream bao = new ByteArrayOutputStream();
         while((bytesRead = input.read(buff)) != -1) {
            bao.write(buff, 0, bytesRead);
         }
         input.close();
		this.photo = bao.toByteArray();
		
	}
	
	
}
