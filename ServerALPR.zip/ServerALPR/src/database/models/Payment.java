package models;

public class Payment {

	private int Id;
	private int PhotographyData_Id;
	private int Advertising_Id;
	
	public Payment()
	{
	}
	
	public int getId()
	{
		return this.Id;
	}
	public int getPhotographyDataId()
	{
		return this.PhotographyData_Id;
	}
	public int getAdvertisingId()
	{
		return this.Advertising_Id;
	}
	
	public void setId(int id)
	{
		this.Id = id;
	}
	public void setPhotographyDataId(int photographydataid)
	{
		this.PhotographyData_Id = photographydataid;
	}
	public void setAdvertisingId(int advertisingid)
	{
		this.Advertising_Id = advertisingid;
	}
}
