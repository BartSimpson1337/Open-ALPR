package models;

import java.sql.Date;
import java.sql.Time;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class Send {

	private int Id;
	private Date send_date;
	private Time send_time;
	private Date executed_date;
	private Time executed_time;
	private int Client_Id;
	
	public Send()
	{
	}
	
	public int getId()
	{
		return this.Id;
	}
	public Date getSendDate()
	{
		return this.send_date;
	}
	public Time getSendTime()
	{
		return this.send_time;
	}
	public Date getExecutedDate()
	{
		return this.executed_date;
	}
	public Time getExecutedTime()
	{
		return this.executed_time;
	}
	public int getClientId()
	{
		return this.Client_Id;
	}
	
	public void setId(int id)
	{
		this.Id = id;
	}
	public void setSendDate(String date)
	{
		try
		{
			DateFormat formated = new SimpleDateFormat("yyyy/MM/dd");
			java.sql.Date sqlDate = new java.sql.Date(formated.parse(date).getTime());
			
			this.send_date = sqlDate;
		}
		catch(Exception e){}
		
	}
	public void setSendTime(String time) 
	{
		try {
			DateFormat formated = new SimpleDateFormat("hh:mm:ss");
			java.sql.Time sqlTime = new java.sql.Time(formated.parse(time).getTime());
			
			this.send_time = sqlTime;
		}
		catch(Exception e){}
		
	}
	public void setExecutedDate(String date) 
	{
		try {
			DateFormat formated = new SimpleDateFormat("yyyy/MM/dd");
			java.sql.Date sqlDate = new java.sql.Date(formated.parse(date).getTime());
			
			this.executed_date = sqlDate;
		}
		catch(Exception e){}
	}
	public void setExecutedTime(String time)
	{
		try {
			DateFormat formated = new SimpleDateFormat("hh:mm:ss");
			java.sql.Time sqlTime = new java.sql.Time(formated.parse(time).getTime());
			
			this.executed_time = sqlTime;
		}
		catch(Exception e){}
		
	}
	public void setClientId(int clientid)
	{
		this.Client_Id = clientid;
	}
}
