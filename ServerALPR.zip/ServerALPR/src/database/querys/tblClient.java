package querys;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import javax.sql.rowset.CachedRowSet;
import javax.sql.rowset.WebRowSet;
import models.Client;

public class tblClient {
	
	public static final String DRIVER = "org.apache.derby.jdbc.ClientDriver"; 
	private static String JDBC_URL = "jdbc:derby://localhost:1527/alprDB;create=true;user=admin;password=security";
	private Connection connection;
	
	public tblClient()
	{
		createConnection();
	}
	private void createConnection()
	{
		try
		{
			Class.forName(DRIVER).newInstance();
			this.connection = DriverManager.getConnection(JDBC_URL);
		}
		catch(Exception e)
		{
			System.out.println("Connection refused!");
		}
	}
	public void closeConnection() throws SQLException
	{
		this.connection.close();
	}
	public long insert(Client client) throws SQLException
	{	
		long key = -1L;
		PreparedStatement ps = this.connection.prepareStatement("INSERT INTO Client(name, birth_date, contact, email, password, account_balance, activity) VALUES (?, ?, ?, ?, ?, ?, ?)", Statement.RETURN_GENERATED_KEYS);
			ps.setString(1, client.getName());
			ps.setDate(2, client.getBirthDate());
			ps.setInt(3, client.getContact());
			ps.setString(4, client.getEmail());
			ps.setString(5, client.getPassword());
			ps.setBigDecimal(6, client.getAccountBalance());
			ps.setBoolean(7, false);
			
			ps.execute();
			ResultSet rs = ps.getGeneratedKeys();
				if(rs.next())
				{
					key = rs.getLong(1);
				}
			
		return key;
	}
	public ResultSet selectAll() throws SQLException
	{
		String SQL_STATEMENT = "SELECT * FROM Client";
			return displayResults(SQL_STATEMENT);
	}
	public ResultSet selectBy(int id) throws SQLException
	{
		String SQL_STATEMENT = "SELECT * FROM Client WHERE Id = "+Integer.toString(id)+"";
			return displayResults(SQL_STATEMENT);
	}
	public ResultSet checkUnique(String email) throws SQLException
	{
		String SQL_STATEMENT = "SELECT COUNT(*) FROM Client WHERE email = '"+email+"'";
			return displayResults(SQL_STATEMENT);
	}
	public void updateBy(Client client) throws SQLException
	{
		this.connection.createStatement().execute("UPDATE Client SET name = '"+client.getName()+"', birth_date = '"+client.getBirthDate()+"', contact = "+client.getContact()+", email = '"+client.getEmail()+"', password = '"+client.getPassword()+"', account_balance = "+client.getAccountBalance()+" WHERE Id = "+client.getId()+"");
	}
	public void updateAccountBalance(int id, BigDecimal value) throws SQLException
	{
		this.connection.createStatement().execute("UPDATE Client SET account_balance = "+value+" WHERE Id = "+Integer.valueOf(id)+"");
	}
	public void deleteBy(int id) throws SQLException
	{
		this.connection.createStatement().execute("DELETE FROM Client WHERE Id = "+Integer.toString(id)+"");
	}
	public void deleteAll() throws SQLException
	{
		this.connection.createStatement().execute("DELETE FROM Client");
	}
	public void dropTable() throws SQLException
	{
		String SQL_STATEMENT = "DROP TABLE Client";
		this.connection.createStatement().execute(SQL_STATEMENT);
	}
	
	public boolean login(String email, String password) throws SQLException
	{
		boolean state = false;
		String SQL_STATEMENT = "SELECT * FROM Client WHERE email = '"+email+"' AND password = '"+password+"' AND activity = "+false+"";

		ResultSet rs = displayResults(SQL_STATEMENT);
		if(rs.next())
		{
			try
			{
				this.connection.createStatement().execute("UPDATE Client SET activity = "+true+" WHERE Id = "+rs.getInt(1)+"");
				state = true;
			}
			catch(SQLException e)
			{
				state = false;
			}
		}
		rs.close();
		return state;
	}
	public boolean logout(int id) throws SQLException 
	{
		boolean state = false;
		String SQL_STATEMENT = "SELECT * FROM Client WHERE Id = "+id+"";
		ResultSet rs = displayResults(SQL_STATEMENT);
		
		while(rs.next())
		{
			if(rs.getBoolean(8) == true)
			{
				try{
					this.connection.createStatement().execute("UPDATE Client SET activity = "+false+" WHERE Id = "+id+"");
					state = true;
				}
				catch(SQLException e)
				{
					state = false;
				}
			}
		}
		rs.close();
		return state;
		
	}
	public ResultSet myId(String email) throws SQLException
	{
		String SQL_STATEMENT = "SELECT Id FROM Client WHERE email = '"+email+"'";
		return displayResults(SQL_STATEMENT);
	}
	
	private ResultSet displayResults(String SQL_STATEMENT) throws SQLException
	{
		
		Statement statement = this.connection.createStatement();
		ResultSet resultSet = statement.executeQuery(SQL_STATEMENT);
		
		return resultSet;
	}

}
