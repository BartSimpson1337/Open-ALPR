package querys;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import models.Advertising;
import models.Vehicle;

public class tblAdvertising {

	public static final String DRIVER = "org.apache.derby.jdbc.ClientDriver"; 
	private static String JDBC_URL = "jdbc:derby://localhost:1527/alprDB;create=true;user=admin;password=security";
	private Connection connection;
	
	
	public tblAdvertising() throws SQLException
	{
		createConnection();
	}
	private void createConnection()
	{
		try
		{
			Class.forName(DRIVER).newInstance();
			this.connection = DriverManager.getConnection(JDBC_URL);
		}
		catch(Exception e)
		{
			System.out.println("Connection refused!");
		}
	}
	public void closeConnection() throws SQLException
	{
		this.connection.close();
	}
	public void insert(Advertising advertising) throws SQLException
	{
		this.connection.createStatement().execute("INSERT INTO Advertising(date, title, reward, localization, description, Vehicle_Id, activity) VALUES ('"+advertising.getDate()+"', '"+advertising.getTitle()+"', "+advertising.getReward()+", '"+advertising.getLocalization()+"', '"+advertising.getDescription()+"', "+advertising.getVehicleId()+", "+true+")");
	}
	public ResultSet selectAll() throws SQLException
	{
		String SQL_STATEMENT = "SELECT * FROM Advertising WHERE activity = "+true+"";
			return displayResults(SQL_STATEMENT);
	}
	public ResultSet selectBy(int id) throws SQLException
	{
		String SQL_STATEMENT = "SELECT * FROM Advertising WHERE Id = "+Integer.toString(id)+"";
			return displayResults(SQL_STATEMENT);
	}
	public ResultSet selectVehicle() throws SQLException
	{
		String SQL_STATEMENT = "SELECT Advertising.Id, Advertising.reward, Vehicle.plate FROM Client JOIN Vehicle ON Client.Id = Vehicle.Client_Id JOIN Advertising ON Vehicle.Id = Advertising.Vehicle_Id WHERE Advertising.activity = "+true+"";
			return displayResults(SQL_STATEMENT);
	}
	public ResultSet selectClient(int advertising_id) throws SQLException
	{
		String SQL_STATEMENT = "SELECT * FROM Client JOIN Vehicle ON Client.Id = Vehicle.Client_Id JOIN Advertising ON Vehicle.Id = Advertising.Vehicle_Id WHERE Advertising.Id = "+Integer.toString(advertising_id)+"";
			return displayResults(SQL_STATEMENT);
	}
	public ResultSet selectAdvertisingClient(int client_id) throws SQLException
	{
		String SQL_STATEMENT = "SELECT Advertising.Id, Advertising.date, Advertising.title, Advertising.reward, Advertising.localization, Advertising.description, Advertising.Vehicle_Id, Advertising.activity FROM Client JOIN Vehicle ON Client.Id = Vehicle.Client_Id JOIN Advertising ON Vehicle.Id = Advertising.Vehicle_Id WHERE Client.Id = "+client_id+" AND Advertising.activity = "+true+"";
		return displayResults(SQL_STATEMENT);
	}
	public ResultSet selectActiveAdvertisings() throws SQLException
	{
		String SQL_STATEMENT = "SELECT * FROM Advertising WHERE activity = "+true+"";
			return displayResults(SQL_STATEMENT);
	}
	public void updateBy(Advertising advertising) throws SQLException
	{
		this.connection.createStatement().execute("UPDATE Advertising SET date = '"+advertising.getDate()+"', title = '"+advertising.getTitle()+"', reward = "+advertising.getReward()+", localization = '"+advertising.getLocalization()+"', description = '"+advertising.getDescription()+"', Vehicle_Id = "+advertising.getVehicleId()+" WHERE Id = "+advertising.getId()+"");
	}
	public void updateActivity(int id, boolean activity) throws SQLException
	{
		this.connection.createStatement().execute("UPDATE Advertising SET activity = "+activity+" WHERE Id = "+Integer.valueOf(id)+"");
	}
	public void deleteBy(int id) throws SQLException
	{
		this.connection.createStatement().execute("DELETE FROM Advertising WHERE Id = "+Integer.toString(id)+"");
	}
	public void deleteAll() throws SQLException
	{
		this.connection.createStatement().execute("DELETE FROM Advertising");
	}
	public void dropTable() throws SQLException
	{
		String SQL_STATEMENT = "DROP TABLE Advertising";
		this.connection.createStatement().execute(SQL_STATEMENT);
	}
	private ResultSet displayResults(String SQL_STATEMENT) throws SQLException
	{
		Statement statement = this.connection.createStatement();
		ResultSet resultSet = statement.executeQuery(SQL_STATEMENT);
		return resultSet;
	}
}
