package querys;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import models.Client;
import models.Send;

public class tblSend {

	public static final String DRIVER = "org.apache.derby.jdbc.ClientDriver"; 
	private static String JDBC_URL = "jdbc:derby://localhost:1527/alprDB;create=true;user=admin;password=security";
	private Connection connection;
	
	public tblSend() throws SQLException
	{
		createConnection();
	}
	private void createConnection()
	{
		try
		{
			Class.forName(DRIVER).newInstance();
			this.connection = DriverManager.getConnection(JDBC_URL);
		}
		catch(Exception e)
		{
			System.out.println("Connection refused!");
		}
	}
	public void closeConnection() throws SQLException
	{
		this.connection.close();
	}
	public long insert(Send send) throws SQLException
	{
		long key = -1L;
		PreparedStatement ps = this.connection.prepareStatement("INSERT INTO Send(send_date, send_time, executed_date, executed_time, Client_Id) VALUES ( ?, ?, ?, ?, ?)", Statement.RETURN_GENERATED_KEYS);
			ps.setDate(1, send.getSendDate());
			ps.setTime(2, send.getSendTime());
			ps.setDate(3, send.getExecutedDate());
			ps.setTime(4, send.getExecutedTime());
			ps.setInt(5, send.getClientId());
			ps.execute();
				ResultSet rs = ps.getGeneratedKeys();
					if(rs.next())
					{
						key = rs.getLong(1);
					}
			return key;
	}
	public ResultSet selectAll() throws SQLException
	{
		String SQL_STATEMENT = "SELECT * FROM Send";
			return displayResults(SQL_STATEMENT);
	}
	public ResultSet selectBy(int id) throws SQLException
	{
		String SQL_STATEMENT = "SELECT * FROM Send WHERE Id = "+Integer.toString(id)+"";
			return displayResults(SQL_STATEMENT);
	}
	public void updateBy(Send send) throws SQLException
	{
		this.connection.createStatement().execute("UPDATE Send SET send_date = '"+send.getSendDate()+"', send_time = '"+send.getSendTime()+"', executed_date = '"+send.getExecutedDate()+"', executed_time = '"+send.getExecutedTime()+"', Client_Id = "+send.getClientId()+" WHERE Id = "+send.getId()+"");
	}
	public void deleteBy(int id) throws SQLException
	{
		this.connection.createStatement().execute("DELETE FROM Send WHERE Id = "+Integer.toString(id)+"");
	}
	public void deleteAll() throws SQLException
	{
		this.connection.createStatement().execute("DELETE FROM Send");
	}
	public void dropTable() throws SQLException
	{
		String SQL_STATEMENT = "DROP TABLE Send";
		this.connection.createStatement().execute(SQL_STATEMENT);
	}
	private ResultSet displayResults(String SQL_STATEMENT) throws SQLException
	{
		Statement statement = this.connection.createStatement();
		ResultSet resultSet = statement.executeQuery(SQL_STATEMENT);
		return resultSet;
	}

}
