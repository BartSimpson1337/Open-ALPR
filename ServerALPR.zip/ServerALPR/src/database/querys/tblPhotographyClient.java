package querys;

import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import models.Photography;
import models.PhotographyClient;

public class tblPhotographyClient {

	public static final String DRIVER = "org.apache.derby.jdbc.ClientDriver"; 
	private static String JDBC_URL = "jdbc:derby://localhost:1527/alprDB;create=true;user=admin;password=security";
	private Connection connection;
	
	public tblPhotographyClient() throws SQLException
	{
		createConnection();
	}
	private void createConnection()
	{
		try
		{
			Class.forName(DRIVER).newInstance();
			this.connection = DriverManager.getConnection(JDBC_URL);
		}
		catch(Exception e)
		{
			System.out.println("Connection refused!");
		}
	}
	public void closeConnection() throws SQLException
	{
		this.connection.close();
	}
	public void insert(PhotographyClient photographyClient) throws SQLException
	{
		Blob blob = this.connection.createBlob();
			blob.setBytes(1, photographyClient.getPhoto());
		
		PreparedStatement ps = this.connection.prepareStatement("INSERT INTO PhotographyClient(Id, photo) VALUES (?, ?)");
			
			ps.setInt(1, photographyClient.getId());
			ps.setBlob(2, blob);
			ps.execute();	
	}
	public ResultSet selectAll() throws SQLException
	{
		String SQL_STATEMENT = "SELECT * FROM PhotographyClient";
			return displayResults(SQL_STATEMENT);
	}
	public ResultSet selectBy(int id) throws SQLException
	{
		String SQL_STATEMENT = "SELECT * FROM PhotographyClient WHERE Id = "+Integer.toString(id)+"";
			return displayResults(SQL_STATEMENT);
	}
	public void updateBy(PhotographyClient photographyClient) throws SQLException
	{
		Blob blob = this.connection.createBlob();
		blob.setBytes(1, photographyClient.getPhoto());
		
		PreparedStatement ps = this.connection.prepareStatement("UPDATE PhotographyClient SET photo = ? WHERE Id = "+photographyClient.getId()+"");
			ps.setBlob(1, blob);
			ps.execute();
	}
	public void deleteBy(int id) throws SQLException
	{
		this.connection.createStatement().execute("DELETE FROM PhotographyClient WHERE Id = "+Integer.toString(id)+"");
	}
	public void deleteAll() throws SQLException
	{
		this.connection.createStatement().execute("DELETE FROM PhotographyClient");
	}
	public void dropTable() throws SQLException
	{
		String SQL_STATEMENT = "DROP TABLE PhotographyClient";
		this.connection.createStatement().execute(SQL_STATEMENT);
	}
	private ResultSet displayResults(String SQL_STATEMENT) throws SQLException
	{
		Statement statement = this.connection.createStatement();
		ResultSet resultSet = statement.executeQuery(SQL_STATEMENT);
		return resultSet;
	}
}
