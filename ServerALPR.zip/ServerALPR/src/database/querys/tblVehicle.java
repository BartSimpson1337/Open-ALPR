package querys;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import models.Client;
import models.Vehicle;

public class tblVehicle {
	
	public static final String DRIVER = "org.apache.derby.jdbc.ClientDriver"; 
	private static String JDBC_URL = "jdbc:derby://localhost:1527/alprDB;create=true;user=admin;password=security";
	private Connection connection;
	
	public tblVehicle() throws SQLException
	{
		createConnection();
	}
	private void createConnection()
	{
		try
		{
			Class.forName(DRIVER).newInstance();
			this.connection = DriverManager.getConnection(JDBC_URL);
		}
		catch(Exception e)
		{
			System.out.println("Connection refused!");
		}
	}
	public void closeConnection() throws SQLException
	{
		this.connection.close();
	}
	public long insert(Vehicle vehicle) throws SQLException
	{
		
		long key = -1L;
		PreparedStatement ps = this.connection.prepareStatement("INSERT INTO Vehicle(plate, brand, model, registration_year, color, fuel, hp, cc, description, Client_Id, visibility) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", Statement.RETURN_GENERATED_KEYS);
			ps.setString(1, vehicle.getPlate());
			ps.setString(2, vehicle.getBrand());
			ps.setString(3, vehicle.getModel());
			ps.setInt(4, vehicle.getRegistrationYear());
			ps.setString(5, vehicle.getColor());
			ps.setString(6, vehicle.getFuel());
			ps.setInt(7, vehicle.getHP());
			ps.setInt(8, vehicle.getCC());
			ps.setString(9, vehicle.getDescription());
			ps.setInt(10, vehicle.getClientId());
			ps.setBoolean(11, true);
			ps.execute();
				ResultSet rs = ps.getGeneratedKeys();
					if(rs.next())
					{
						key = rs.getLong(1);
					}
			return key;
	}
	public ResultSet selectAll() throws SQLException
	{
		String SQL_STATEMENT = "SELECT * FROM Vehicle";
			return displayResults(SQL_STATEMENT);
	}
	public ResultSet selectBy(int id) throws SQLException
	{
		String SQL_STATEMENT = "SELECT * FROM Vehicle WHERE Id = "+Integer.toString(id)+"";
			return displayResults(SQL_STATEMENT);
	}
	public ResultSet selectClient(int clientid) throws SQLException
	{
		String SQL_STATEMENT = "SELECT * FROM Vehicle WHERE Client_Id = "+clientid+" AND visibility = "+true+"";
			return displayResults(SQL_STATEMENT);
	}
	public ResultSet selectClient_v2(int clientid) throws SQLException
	{
		String SQL_STATEMENT = "SELECT * FROM Vehicle WHERE Client_Id = "+clientid+"";
			return displayResults(SQL_STATEMENT);
	}
	public ResultSet checkUnique(String plate) throws SQLException
	{
		String SQL_STATEMENT = "SELECT COUNT(*) FROM Vehicle WHERE plate = '"+plate+"'";
			return displayResults(SQL_STATEMENT);
	}
	public void updateBy(Vehicle vehicle) throws SQLException
	{
		this.connection.createStatement().execute("UPDATE Vehicle SET plate = '"+vehicle.getPlate()+"', brand = '"+vehicle.getBrand()+"', model = '"+vehicle.getModel()+"', registration_year = "+vehicle.getRegistrationYear()+", color = '"+vehicle.getColor()+"', fuel = '"+vehicle.getFuel()+"', hp = "+vehicle.getHP()+", cc = "+vehicle.getCC()+", description = '"+vehicle.getDescription()+"', Client_Id = "+vehicle.getClientId()+" WHERE Id = "+vehicle.getId()+"");
	}
	public void activateVehicle(int id) throws SQLException
	{
		this.connection.createStatement().execute("UPDATE Vehicle SET visibility = "+true+" WHERE Id = "+String.valueOf(id)+"");
	}
	public void removeVehicle(int id) throws SQLException
	{
		this.connection.createStatement().execute("UPDATE Vehicle SET visibility = "+false+" WHERE Id = "+String.valueOf(id)+"");
	}
	
	public void deleteBy(int id) throws SQLException
	{
		this.connection.createStatement().execute("DELETE FROM Vehicle WHERE Id = "+Integer.toString(id)+"");
	}
	public void deleteAll() throws SQLException
	{
		this.connection.createStatement().execute("DELETE FROM Vehicle");
	}
	public void dropTable() throws SQLException
	{
		String SQL_STATEMENT = "DROP TABLE Vehicle";
		this.connection.createStatement().execute(SQL_STATEMENT);
	}
	private ResultSet displayResults(String SQL_STATEMENT) throws SQLException
	{
		Statement statement = this.connection.createStatement();
		ResultSet resultSet = statement.executeQuery(SQL_STATEMENT);
		return resultSet;
	}
}
