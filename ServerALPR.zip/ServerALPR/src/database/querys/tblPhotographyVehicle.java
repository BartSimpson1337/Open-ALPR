package querys;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import javax.imageio.ImageIO;

import org.apache.derby.client.am.SqlException;

import models.PhotographyVehicle;

public class tblPhotographyVehicle {

	public static final String DRIVER = "org.apache.derby.jdbc.ClientDriver"; 
	private static String JDBC_URL = "jdbc:derby://localhost:1527/alprDB;create=true;user=admin;password=security";
	private Connection connection;
	
	public tblPhotographyVehicle() throws SQLException 
	{
		createConnection();
	}
	private void createConnection()
	{
		try
		{
			Class.forName(DRIVER).newInstance();
			this.connection = DriverManager.getConnection(JDBC_URL);
		}
		catch(Exception e)
		{
			System.out.println("Connection refused!");
		}
	}
	public void closeConnection() throws SQLException
	{
		this.connection.close();
	}
	public void insert(PhotographyVehicle photographyvehicle) throws SQLException
	{
		Blob blob = this.connection.createBlob();
			blob.setBytes(1, photographyvehicle.getPhoto());
		
		PreparedStatement ps = this.connection.prepareStatement("INSERT INTO PhotographyVehicle(photo, Vehicle_Id) VALUES (?, ?)");
			
			ps.setBlob(1, blob);
			ps.setInt(2, photographyvehicle.getVehicleId());
			ps.execute();
			
	}
	public ResultSet selectAll() throws SQLException
	{
		String SQL_STATEMENT = "SELECT * FROM PhotographyVehicle";
			return displayResults(SQL_STATEMENT);
	}
	public ResultSet selectBy(int id) throws SQLException
	{
		String SQL_STATEMENT = "SELECT * FROM PhotographyVehicle WHERE Id = "+Integer.toString(id)+"";
			return displayResults(SQL_STATEMENT);
	}
	public ResultSet countVehiclePhotos(int id) throws SQLException
	{
		String SQL_STATEMENT = "SELECT COUNT(*) FROM PhotographyVehicle WHERE Vehicle_Id = "+Integer.toString(id)+"";
			return displayResults(SQL_STATEMENT);
	}
	public ResultSet selectByVehicle(int id) throws SQLException
	{
		String SQL_STATEMENT = "SELECT * FROM PhotographyVehicle WHERE Vehicle_Id = "+Integer.toString(id)+"";
			return displayResults(SQL_STATEMENT);
	}
	public void updateBy(PhotographyVehicle photographyvehicle) throws SQLException
	{
		Blob blob = this.connection.createBlob();
		blob.setBytes(1, photographyvehicle.getPhoto());
		PreparedStatement ps = this.connection.prepareStatement("UPDATE PhotographyVehicle SET photo = ?, Vehicle_Id = ? WHERE Id = "+photographyvehicle.getId()+"");
			ps.setBlob(1, blob);
			ps.setInt(2, photographyvehicle.getVehicleId());
			ps.execute();	
	}
	public void deleteBy(int id) throws SQLException
	{
		this.connection.createStatement().execute("DELETE FROM PhotographyVehicle WHERE Id = "+Integer.toString(id)+"");
	}
	public void deleteAll() throws SQLException
	{
		this.connection.createStatement().execute("DELETE FROM PhotographyVehicle");
	}
	public void dropTable() throws SQLException
	{
		String SQL_STATEMENT = "DROP TABLE PhotographyVehicle";
		this.connection.createStatement().execute(SQL_STATEMENT);
	}
	private ResultSet displayResults(String SQL_STATEMENT) throws SQLException
	{
		Statement statement = this.connection.createStatement();
		ResultSet resultSet = statement.executeQuery(SQL_STATEMENT);
		return resultSet;
	}
}
