package querys;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;

import models.Advertising;
import models.Payment;
import querys.tblAdvertising;
import querys.tblClient;
import querys.tblPayment;
import querys.tblPhotographyData;

public class Search {
	
	private String plate;
	private int PhotographyData_Id;
	private int Advertising_Id;
	private int Client1_id;
	private int Client2_id;
	private BigDecimal reward;
	private BigDecimal accountBalance1;
	private BigDecimal accountBalance2;
	
	
	public Search(int photographyDataId,String plate)
	{
		this.PhotographyData_Id = photographyDataId;
		this.plate = plate;
		try {
			searchAdvertisings();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	private void searchAdvertisings() throws SQLException
	{
		tblAdvertising ta = new tblAdvertising();
		ResultSet r = ta.selectVehicle();
		while(r.next())
		{
			if(r.getString(3).equalsIgnoreCase(plate))
			{
				this.Advertising_Id = r.getInt(1);
				this.reward = new BigDecimal(r.getString(2));
				searchClient1();
				searchClient2();
			
				if(this.Client1_id != this.Client2_id)
				{
					payment();	
					ta.updateActivity(Advertising_Id, false);
				}
			}	
		}
		r.close();
		ta.closeConnection();
		
	}
	private void searchClient1() throws SQLException
	{
		tblAdvertising ta = new tblAdvertising();
			ResultSet r = ta.selectClient(this.Advertising_Id);
			while(r.next())
			{
				this.Client1_id = r.getInt(1);
				this.accountBalance1 = new BigDecimal(r.getString(7));
			}
			r.close();
		ta.closeConnection();
	}
	private void searchClient2() throws SQLException
	{
		tblPhotographyData tp = new tblPhotographyData();
		ResultSet r = tp.selectClient(this.PhotographyData_Id);
		while(r.next())
		{
			this.Client2_id = r.getInt(1);
			this.accountBalance2 = new BigDecimal(r.getString(7));
		}
		r.close();
		tp.closeConnection();
	}
	private void payment() throws SQLException
	{
		
	
		Payment p = new Payment();
			p.setAdvertisingId(Advertising_Id);
			p.setPhotographyDataId(PhotographyData_Id);
		tblPayment tp = new tblPayment();
			tp.insert(p);
		tp.closeConnection();
		
		tblClient tc = new tblClient();
			tc.updateAccountBalance(Client1_id, this.accountBalance1.subtract(this.reward));
			tc.updateAccountBalance(Client2_id, this.accountBalance2.add(this.reward));
		tc.closeConnection();
		
	}

}
