package querys;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import models.Client;
import models.Payment;

public class tblPayment {

	public static final String DRIVER = "org.apache.derby.jdbc.ClientDriver"; 
	private static String JDBC_URL = "jdbc:derby://localhost:1527/alprDB;create=true;user=admin;password=security";
	private Connection connection;
	
	public tblPayment() throws SQLException
	{
		createConnection();
	}
	private void createConnection()
	{
		try
		{
			Class.forName(DRIVER).newInstance();
			this.connection = DriverManager.getConnection(JDBC_URL);
		}
		catch(Exception e)
		{
			System.out.println("Connection refused!");
		}
	}
	public void closeConnection() throws SQLException
	{
		this.connection.close();
	}
	public void insert(Payment payment) throws SQLException
	{
		this.connection.createStatement().execute("INSERT INTO Payment(PhotographyData_Id, Advertising_Id) VALUES ("+payment.getPhotographyDataId()+", "+payment.getAdvertisingId()+")");
	}
	public ResultSet selectAll() throws SQLException
	{
		String SQL_STATEMENT = "SELECT * FROM Payment";
			return displayResults(SQL_STATEMENT);
	}
	public ResultSet selectBy(int id) throws SQLException
	{
		String SQL_STATEMENT = "SELECT * FROM Payment WHERE Id = "+Integer.toString(id)+"";
			return displayResults(SQL_STATEMENT);
	}
	public ResultSet selectPaymentClient(int clientid) throws SQLException
	{
		String SQL_STATEMENT = "SELECT Payment.Id, Payment.PhotographyData_Id, Payment.Advertising_Id FROM Client JOIN Send ON Client.Id = Send.Client_Id JOIN PhotographyData ON Send.Id = PhotographyData.Send_Id JOIN Payment ON PhotographyData.Id = Payment.PhotographyData_Id WHERE Client.Id = "+clientid+"";
			return displayResults(SQL_STATEMENT);
	}
	public void updateBy(Payment payment) throws SQLException
	{
		this.connection.createStatement().execute("UPDATE Payment SET PhotographyData_Id = "+payment.getPhotographyDataId()+", Advertising_Id = "+payment.getAdvertisingId()+" WHERE Id = "+payment.getId()+"");
	}
	public void deleteBy(int id) throws SQLException
	{
		this.connection.createStatement().execute("DELETE FROM Payment WHERE Id = "+Integer.toString(id)+"");
	}
	public void deleteAll() throws SQLException
	{
		this.connection.createStatement().execute("DELETE FROM Payment");
	}
	public void dropTable() throws SQLException
	{
		String SQL_STATEMENT = "DROP TABLE Payment";
		this.connection.createStatement().execute(SQL_STATEMENT);
	}
	private ResultSet displayResults(String SQL_STATEMENT) throws SQLException
	{
		Statement statement = this.connection.createStatement();
		ResultSet resultSet = statement.executeQuery(SQL_STATEMENT);
		return resultSet;
	}
}
