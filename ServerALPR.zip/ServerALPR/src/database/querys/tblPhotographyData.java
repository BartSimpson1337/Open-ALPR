package querys;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import models.Client;
import models.PhotographyData;

public class tblPhotographyData {

	public static final String DRIVER = "org.apache.derby.jdbc.ClientDriver"; 
	private static String JDBC_URL = "jdbc:derby://localhost:1527/alprDB;create=true;user=admin;password=security";
	private Connection connection;
	
	public tblPhotographyData() throws SQLException
	{
		createConnection();
	}
	private void createConnection()
	{
		try
		{
			Class.forName(DRIVER).newInstance();
			this.connection = DriverManager.getConnection(JDBC_URL);
		}
		catch(Exception e)
		{
			System.out.println("Connection refused!");
		}
	}
	public void closeConnection() throws SQLException
	{
		this.connection.close();
	}
	public long insert(PhotographyData photographydata) throws SQLException
	{
		long key = -1L;
		PreparedStatement ps = this.connection.prepareStatement("INSERT INTO PhotographyData(date, time, geolocation, latitude, longitude, plate, confidence, brand, model, registration_year, color, fuel, hp, cc, Send_Id, visibility) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", Statement.RETURN_GENERATED_KEYS);
			ps.setDate(1, photographydata.getDate());
			ps.setTime(2, photographydata.getTime());
			ps.setString(3, photographydata.getGeolocation());
			ps.setDouble(4, photographydata.getLatitude());
			ps.setDouble(5, photographydata.getLongitude());
			ps.setString(6, photographydata.getPlate());
			ps.setFloat(7, photographydata.getConfidence());
			ps.setString(8, photographydata.getBrand());
			ps.setString(9, photographydata.getModel());
			ps.setInt(10, photographydata.getRegistrationYear());
			ps.setString(11, photographydata.getColor());
			ps.setString(12, photographydata.getFuel());
			ps.setInt(13, photographydata.getHP());
			ps.setInt(14, photographydata.getCC());
			ps.setInt(15, photographydata.getSendId());
			ps.setBoolean(16, true);
			ps.execute();
				ResultSet rs = ps.getGeneratedKeys();
					if(rs.next())
					{
						key = rs.getLong(1);
					}
			
			return key;
	}
	public ResultSet selectAll() throws SQLException
	{
		String SQL_STATEMENT = "SELECT * FROM PhotographyData";
			return displayResults(SQL_STATEMENT);
	}
	public ResultSet selectBy(int id) throws SQLException
	{
		String SQL_STATEMENT = "SELECT * FROM PhotographyData WHERE Id = "+Integer.toString(id)+"";
			return displayResults(SQL_STATEMENT);
	}
	public ResultSet selectClient(int photographydata_id) throws SQLException
	{
		String SQL_STATEMENT = "SELECT * FROM Client JOIN Send ON Client.Id = Send.Client_Id JOIN PhotographyData ON Send.Id = PhotographyData.Send_Id WHERE PhotographyData.Id = "+Integer.toString(photographydata_id)+"";
			return displayResults(SQL_STATEMENT);
	}
	public ResultSet selectPhotographyDataClient(int clientid) throws SQLException
	{
		String SQL_STATEMENT = "SELECT PhotographyData.Id, PhotographyData.date, PhotographyData.time, PhotographyData.geolocation, PhotographyData.latitude, PhotographyData.longitude, PhotographyData.plate, PhotographyData.confidence, PhotographyData.brand, PhotographyData.model, PhotographyData.registration_year, PhotographyData.color, PhotographyData.fuel, PhotographyData.hp, PhotographyData.cc, PhotographyData.Send_Id, Photography.photo FROM Client JOIN Send ON Client.Id = Send.Client_Id JOIN PhotographyData ON Send.Id = PhotographyData.Send_Id JOIN Photography ON PhotographyData.Id = Photography.Id WHERE Client.Id = "+clientid+" AND PhotographyData.visibility = "+true+"";
			return displayResults(SQL_STATEMENT);
	}
	public void updateBy(PhotographyData photographydata) throws SQLException
	{
		this.connection.createStatement().execute("UPDATE PhotographyData SET date = '"+photographydata.getDate()+"', time = '"+photographydata.getTime()+"', geolocation = '"+photographydata.getGeolocation()+"', latitude = "+photographydata.getLatitude()+", longitude = "+photographydata.getLongitude()+", plate = '"+photographydata.getPlate()+"', confidence = "+photographydata.getConfidence()+", brand = '"+photographydata.getBrand()+"', model = '"+photographydata.getModel()+"', registration_year = "+photographydata.getRegistrationYear()+", color = '"+photographydata.getColor()+"', fuel = '"+photographydata.getFuel()+"', hp = "+photographydata.getHP()+", cc = "+photographydata.getCC()+", Send_Id = "+photographydata.getSendId()+" WHERE Id = "+photographydata.getId()+"");
	}
	public void removePhotographyData(int id) throws SQLException
	{
		this.connection.createStatement().execute("UPDATE PhotographyData SET visibility = "+false+" WHERE Id = "+String.valueOf(id)+"");
	}
	public void deleteBy(int id) throws SQLException
	{
		this.connection.createStatement().execute("DELETE FROM PhotographyData WHERE Id = "+Integer.toString(id)+"");
	}
	public void deleteAll() throws SQLException
	{
		this.connection.createStatement().execute("DELETE FROM PhotographyData");
	}
	public void dropTable() throws SQLException
	{
		String SQL_STATEMENT = "DROP TABLE PhotographyData";
		this.connection.createStatement().execute(SQL_STATEMENT);
	}
	private ResultSet displayResults(String SQL_STATEMENT) throws SQLException
	{
		Statement statement = this.connection.createStatement();
		ResultSet resultSet = statement.executeQuery(SQL_STATEMENT);
		return resultSet;
	}
	
}
