
import java.math.BigDecimal;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.net.URLConnection;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.logging.Handler;

import javax.ws.rs.core.UriBuilder;
import javax.xml.ws.Endpoint;

import org.glassfish.hk2.utilities.binding.AbstractBinder;
import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.jdkhttp.JdkHttpHandlerContainerProvider;
import org.glassfish.jersey.jdkhttp.JdkHttpServerFactory;
import org.glassfish.jersey.server.ResourceConfig;
import org.jsoup.helper.HttpConnection;

import querys.DataBase;
import querys.tblAdvertising;
import querys.tblClient;
import querys.tblPayment;
import querys.tblPhotography;
import querys.tblPhotographyData;
import querys.tblSend;
import querys.tblVehicle;
import request.ListOfRequests;
import service.NetworkServices;
import webservice.AlprServerRemote;

import com.sun.net.httpserver.BasicAuthenticator;
import com.sun.net.httpserver.HttpContext;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

import models.Advertising;
import models.Client;
import models.Payment;
import models.PhotographyData;
import models.Send;
import models.Vehicle;

public class main {
	// Webservice host and port
	private final static int port = 9998;
	private final static String host = "http://localhost/";

	public static void main(String[] args) {

		// Inicia os serviços de rede TOR e Privoxy
		NetworkServices.getCredencials();
		NetworkServices.startTorService(); // Connect to tor service
		NetworkServices.startPrivoxyService(); // start privoxy service
		NetworkServices.setProxyServer(); // Set tor default proxy.
		if (NetworkServices.statusTorService() == true && NetworkServices.statusPrivoxyService() == true) {
			System.out.println("Network services started with success!");
		} else {
			System.out.println("Nertwork services not started!");
		}

		try {
			// Inicia a Base de dados
			DataBase db = new DataBase();
			db.startDerbyNet();

			System.out.println("DerbyDB started with success!");
		} catch (Exception e) {
			System.out.println("DerbyDB  not started!");
		}

		ListOfRequests listofrequests = new ListOfRequests();
		listofrequests.multiThreading();
		// Cria um HTTP SERVER associado a um webservice rest.
		URI baseUri = UriBuilder.fromUri(host).port(port).build();
		ResourceConfig config = new ResourceConfig(AlprServerRemote.class);
		// Registering an object that was instancied from AlprServerRemote class
		config.register(new AbstractBinder() {

			@Override
			protected void configure() {
				// TODO Auto-generated method stub
				bind(listofrequests).to(ListOfRequests.class);
			}
		});
		HttpServer server = JdkHttpServerFactory.createHttpServer(baseUri, config);
		HttpContext context = server.createContext("/Authentication", new AlprServerRemote());
		context.setAuthenticator(new BasicAuthenticator("Authentication") {

			@Override
			public boolean checkCredentials(String username, String password) {
				// TODO Auto-generated method stub
				if (username.equals("auth-user") && password.equals("auth-pass")) {
					return true;
				}
				return false;
			}
		});

		// Testa a conecção do webservice.
		try {
			URL url = new URL("http://localhost:9998/WebService/testConnection");
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			
			if(connection.getResponseCode() == 200)
			{
				System.out.println("HTTPServer started with success!");
			}

		} catch (Exception e) {
			System.out.println("HTTPServer not started!");
		}

		listofrequests.take();
	}
}
