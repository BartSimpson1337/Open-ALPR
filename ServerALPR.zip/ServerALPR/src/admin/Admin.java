package admin;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.NoSuchElementException;
import java.util.Scanner;

import querys.DataBase;
import querys.tblClient;
import service.NetworkServices;

public class Admin{

	private static boolean flag = true;
	
	public static void main(String[] args)
	{
	
		while(flag)
		{
			System.out.println("\n###############");
				System.out.println("\tSair - 0");
				System.out.println("\tCreate DB -1");
				System.out.println("\tDisplay Table - 2");
				System.out.println("\tRemove DB - 3");
				System.out.println("\tStart NetworkServices - 4");
				System.out.println("\tStop NetworkServices - 5");
				System.out.println("\tRestart NetworkServices -6");
				System.out.println("\tNetworkServices status - 7");
				System.out.println("\tRemove Client - 8");
			System.out.println("###############");
			System.out.print("Option:");
			Scanner in = new Scanner(System.in);

				try
				{
					int op = Integer.valueOf(in.next());
					if(op >= 0 && op <= 8)
					{
						options(op);
					}
				}
				catch(Exception e)
				{
					System.out.println("Invalid Option!");
				}
		}
	}
	
	private static void options(int option) throws Exception
	{
		switch(option)
		{
		case 0:
			flag = false;
			break;
		case 1:
			Connection connection = createConnection();
				DataBase.createTables(connection);
			closeConnection(connection);
			break;
		case 2:
			System.out.println("###############");
				System.out.println("\t\tTable Advertising - 1");
				System.out.println("\t\tTable Client - 2");
				System.out.println("\t\tTable PhotographyClient - 3");
				System.out.println("\t\tTable PhotographyData - 4");
				System.out.println("\t\tTable Payment - 5");
				System.out.println("\t\tTable Send - 6");
				System.out.println("\t\tTable Vehicle - 7");
				System.out.println("\t\tTable Photography - 8");
				System.out.println("\t\tTable PhotographyVehicle - 9");
			System.out.println("###############");
			System.out.print("Table:");
			Scanner in = new Scanner(System.in);
			try
			{
				displayTable(Integer.valueOf(in.next()));
			}
			catch(Exception e)
			{
				System.out.println("Invalid table!");
			}
			
			break;
		case 3:
			removeDB();
			break;
		case 4:
			startNetorkServices();
			break;
		case 5:
			stopNetworkServices();
			break;
		case 6:
			restartNetworkServices();
			break;
		case 7:
			NetworkServicesStats();
			break;
		case 8:
			System.out.print("Client:");
			Scanner input = new Scanner(System.in);
			try
			{
				deleteClient(Integer.valueOf(input.next()));
			}
			catch(Exception e)
			{
			}
			break;
		}
	}
	public static void displayTable(int tableid) throws Exception {
		// TODO Auto-generated method stub
		Connection connection = createConnection();
		DataBase.displayTable(connection, tableid);
		connection.close();
	}

	public static void removeDB() throws Exception {
		// TODO Auto-generated method stub
		Connection connection = createConnection();
		DataBase.removeDB(connection);
		connection.close();
	}


	public static void startNetorkServices() throws Exception {
		// TODO Auto-generated method stub
			NetworkServices.startPrivoxyService();
			NetworkServices.startTorService();
			NetworkServices.setProxyServer();

	}

	public static void stopNetworkServices() throws Exception {
		// TODO Auto-generated method stub
			NetworkServices.stopPrivoxyService();
			NetworkServices.stopTorService();

	}
	public static void restartNetworkServices() throws Exception
	{
			NetworkServices.restartPrivoxyService();
			NetworkServices.restartTorService();
	}

	public static void NetworkServicesStats() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("Privoxy:"+NetworkServices.statusPrivoxyService());
		System.out.println("Tor:"+NetworkServices.statusTorService());
	}


	public static void deleteClient(int id) throws Exception {
		// TODO Auto-generated method stub
		tblClient tc = new tblClient();
			tc.deleteBy(id);
		tc.closeConnection();
	}
	
	private static Connection createConnection()
	{
		String DRIVER = "org.apache.derby.jdbc.ClientDriver"; 
		String JDBC_URL = "jdbc:derby://localhost:1527/alprDB;create=true;user=admin;password=security";
		try
		{
			Class.forName(DRIVER).newInstance();
			return DriverManager.getConnection(JDBC_URL);
		}
		catch(Exception e)
		{
			System.out.println("Connection refused!");
		}
		return null;
	}
	private static void closeConnection(Connection connection)
	{
		try {
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	


}
